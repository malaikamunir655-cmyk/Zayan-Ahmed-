import { StoryContainer } from './components/story/StoryContainer';

export default function App() {
  return <StoryContainer />;
}
