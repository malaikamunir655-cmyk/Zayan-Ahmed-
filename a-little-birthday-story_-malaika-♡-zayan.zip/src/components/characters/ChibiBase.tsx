import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { CharacterPose, LookDirection } from '../../types/story';

export type CharacterIdentity = 'malaika' | 'zayan';

interface ChibiBaseProps {
  identity: CharacterIdentity;
  pose?: CharacterPose;
  lookDirection?: LookDirection;
  facing?: 'left' | 'right';
  size?: number;
  className?: string;
  onTap?: () => void;
  ariaLabel?: string;
}

const PALETTES = {
  malaika: {
    hairBase: '#F3D27A',
    hairLight: '#FCE9AC',
    hairShadow: '#D9AF52',
    hairOutline: '#7F612B',
    eyeTop: '#336BA3',
    eyeMid: '#5A9BD4',
    eyeBottom: '#A6D6FA',
    skinBase: '#FFE8DD',
    skinShadow: '#F6CFC0',
    blush: '#F79FB0',
    ribbon: '#8EB8DC',
    innerEar: '#F4BAC7',
  },
  zayan: {
    hairBase: '#2A2120',
    hairLight: '#463836',
    hairShadow: '#1A1312',
    hairOutline: '#140E0E',
    eyeTop: '#1D1719',
    eyeMid: '#3A2E32',
    eyeBottom: '#6B5960',
    skinBase: '#FCE3D6',
    skinShadow: '#F2C7B6',
    blush: '#F596A8',
    ribbon: '#7CAAD3',
    innerEar: '#E7B0BE',
  },
};

export const ChibiBase: React.FC<ChibiBaseProps> = ({
  identity,
  pose = 'standing',
  lookDirection = 'center',
  facing = 'right',
  size = 180,
  className = '',
  onTap,
  ariaLabel,
}) => {
  const prefersReducedMotion = useReducedMotion();
  const [isBlinking, setIsBlinking] = useState(false);
  const [tapBounce, setTapBounce] = useState(false);

  const reactId = React.useId();
  const p = PALETTES[identity];
  const uid = `chibi-${identity}-${reactId.replace(/:/g, '')}`;

  // Natural blinking loop
  useEffect(() => {
    if (prefersReducedMotion) return;
    if (pose === 'sleeping' || pose === 'hugging' || pose === 'celebrating') return;

    let timeoutId: number;
    const scheduleBlink = () => {
      const delay = 2400 + Math.random() * 2400;
      timeoutId = window.setTimeout(() => {
        setIsBlinking(true);
        window.setTimeout(() => {
          setIsBlinking(false);
          scheduleBlink();
        }, 145);
      }, delay);
    };
    scheduleBlink();
    return () => window.clearTimeout(timeoutId);
  }, [prefersReducedMotion, pose]);

  const handleClick = () => {
    setTapBounce(true);
    window.setTimeout(() => setTapBounce(false), 450);
    onTap?.();
  };

  // Eye pupil offset based on lookDirection
  const pupilShiftX = lookDirection === 'left' ? -3.2 : lookDirection === 'right' ? 3.2 : 0;
  const headTilt =
    pose === 'blushing'
      ? identity === 'malaika'
        ? 6
        : -6
      : pose === 'surprised'
        ? -4
        : pose === 'sleeping'
          ? 9
          : pose === 'waving'
            ? -3
            : lookDirection === 'left'
              ? -3
              : lookDirection === 'right'
                ? 3
                : 0;

  const isClosedEyes = pose === 'sleeping' || pose === 'hugging' || isBlinking;
  const isHappyArcEyes = pose === 'celebrating';
  const isSurprised = pose === 'surprised';
  const isBlushing = pose === 'blushing' || pose === 'hugging' || tapBounce;
  const isSitting = pose === 'sitting';
  const isWalking = pose === 'walking';
  const isDancing = pose === 'dancing';
  const isWaving = pose === 'waving' || pose === 'celebrating';
  const isHoldingLetter = pose === 'holding-letter';
  const isHoldingCake = pose === 'holding-cake';

  // Body motion variants
  const bodyAnimate = prefersReducedMotion
    ? {}
    : tapBounce
      ? { y: [0, -14, 0], scale: [1, 1.05, 1] }
      : isWalking
        ? { y: [0, -4, 0, -4, 0], rotate: [-1.5, 1.5, -1.5] }
        : isDancing
          ? { y: [0, -9, 0, -9, 0], rotate: [-5, 5, -5] }
          : pose === 'celebrating'
            ? { y: [0, -12, 0], scale: [1, 1.03, 1] }
            : pose === 'peeking'
              ? { y: [0, -3, 0] }
              : { y: [0, -3, 0] };

  const bodyTransition = tapBounce
    ? { duration: 0.42, ease: 'easeOut' as const }
    : isWalking
      ? { duration: 0.75, repeat: Infinity, ease: 'easeInOut' as const }
      : isDancing
        ? { duration: 0.9, repeat: Infinity, ease: 'easeInOut' as const }
        : pose === 'celebrating'
          ? { duration: 0.85, repeat: Infinity, ease: 'easeInOut' as const }
          : { duration: 3.2, repeat: Infinity, ease: 'easeInOut' as const };

  return (
    <motion.div
      role={onTap ? 'button' : undefined}
      tabIndex={onTap ? 0 : undefined}
      aria-label={ariaLabel || `${identity === 'malaika' ? 'Malaika' : 'Zayan'} chibi character`}
      onClick={onTap ? handleClick : undefined}
      onKeyDown={
        onTap
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleClick();
              }
            }
          : undefined
      }
      animate={bodyAnimate}
      transition={bodyTransition}
      className={`relative inline-flex items-center justify-center select-none ${
        onTap ? 'cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5C93C4] rounded-3xl' : ''
      } ${className}`}
      style={{ width: size, height: size * 1.15 }}
    >
      <svg
        viewBox="0 0 220 252"
        className="w-full h-full chibi-sticker overflow-visible"
        style={{
          transform: facing === 'left' ? 'scaleX(-1)' : undefined,
        }}
      >
        <defs>
          <linearGradient id={`${uid}-iris`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={p.eyeTop} />
            <stop offset="52%" stopColor={p.eyeMid} />
            <stop offset="100%" stopColor={p.eyeBottom} />
          </linearGradient>
          <linearGradient id={`${uid}-hoodie`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2F3441" />
            <stop offset="55%" stopColor="#222630" />
            <stop offset="100%" stopColor="#191C24" />
          </linearGradient>
          <linearGradient id={`${uid}-bell`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FFE68C" />
            <stop offset="55%" stopColor="#F2C044" />
            <stop offset="100%" stopColor="#D69E24" />
          </linearGradient>
          <radialGradient id={`${uid}-blush`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={p.blush} stopOpacity="0.85" />
            <stop offset="100%" stopColor={p.blush} stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Ground soft shadow */}
        {pose !== 'peeking' && (
          <ellipse cx="110" cy="237" rx="44" ry="8" fill="rgba(64, 90, 115, 0.14)" />
        )}

        {/* Black Cat Tail behind character */}
        <g className={prefersReducedMotion ? '' : 'animate-tail-sway'}>
          <path
            d="M 132 198 C 166 196, 185 166, 174 142 C 168 130, 155 135, 160 147 C 166 161, 154 182, 130 185 Z"
            fill="#222630"
            stroke="#151820"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          <path
            d="M 164 146 C 169 156, 164 172, 149 180"
            fill="none"
            stroke="#3B4152"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </g>

        {/* Back Hair (Malaika longer shoulder locks) */}
        {identity === 'malaika' && (
          <g>
            <path
              d="M 55 96 C 46 125, 49 154, 62 162 C 67 148, 70 130, 72 110 Z"
              fill={p.hairShadow}
              stroke={p.hairOutline}
              strokeWidth="2.2"
              strokeLinejoin="round"
            />
            <path
              d="M 165 96 C 174 125, 171 154, 158 162 C 153 148, 150 130, 148 110 Z"
              fill={p.hairShadow}
              stroke={p.hairOutline}
              strokeWidth="2.2"
              strokeLinejoin="round"
            />
          </g>
        )}

        {/* LEGS & SHOES */}
        {!isSitting ? (
          <g>
            {/* Left Leg */}
            <motion.g
              animate={
                prefersReducedMotion
                  ? {}
                  : isWalking
                    ? { rotate: [-14, 14, -14] }
                    : isDancing
                      ? { rotate: [-10, 8, -10] }
                      : {}
              }
              transition={{ duration: 0.75, repeat: Infinity, ease: 'easeInOut' }}
              style={{ transformOrigin: '94px 202px' }}
            >
              <rect x="85" y="200" width="16" height="24" rx="7" fill={p.skinBase} stroke="#362C2B" strokeWidth="2.2" />
              {/* Cozy dark shoe */}
              <path
                d="M 81 220 C 81 215, 102 215, 103 222 C 103 229, 81 230, 81 220 Z"
                fill="#2C3240"
                stroke="#181B24"
                strokeWidth="2.2"
              />
              <path d="M 84 226 L 100 226" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" opacity="0.7" />
            </motion.g>

            {/* Right Leg */}
            <motion.g
              animate={
                prefersReducedMotion
                  ? {}
                  : isWalking
                    ? { rotate: [14, -14, 14] }
                    : isDancing
                      ? { rotate: [8, -10, 8] }
                      : {}
              }
              transition={{ duration: 0.75, repeat: Infinity, ease: 'easeInOut' }}
              style={{ transformOrigin: '126px 202px' }}
            >
              <rect x="119" y="200" width="16" height="24" rx="7" fill={p.skinBase} stroke="#362C2B" strokeWidth="2.2" />
              <path
                d="M 117 222 C 118 215, 139 215, 139 220 C 139 230, 117 229, 117 222 Z"
                fill="#2C3240"
                stroke="#181B24"
                strokeWidth="2.2"
              />
              <path d="M 120 226 L 136 226" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" opacity="0.7" />
            </motion.g>
          </g>
        ) : (
          /* Sitting pose legs tucked forward */
          <g>
            <ellipse cx="89" cy="214" rx="14" ry="10" fill="#2C3240" stroke="#181B24" strokeWidth="2.2" />
            <ellipse cx="131" cy="214" rx="14" ry="10" fill="#2C3240" stroke="#181B24" strokeWidth="2.2" />
            <ellipse cx="86" cy="212" rx="6" ry="3.5" fill="#464E62" />
            <ellipse cx="134" cy="212" rx="6" ry="3.5" fill="#464E62" />
          </g>
        )}

        {/* OVERSIZED BLACK CAT HOODIE TORSO */}
        <g>
          {/* Hoodie body */}
          <path
            d="M 75 142 C 66 164, 62 192, 68 205 C 86 211, 134 211, 152 205 C 158 192, 154 164, 145 142 Z"
            fill={`url(#${uid}-hoodie)`}
            stroke="#151820"
            strokeWidth="2.6"
            strokeLinejoin="round"
          />
          {/* Hoodie pocket */}
          <path
            d="M 86 178 Q 110 175 134 178 L 138 197 Q 110 201 82 197 Z"
            fill="#1D202A"
            stroke="#343A4B"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
          {/* Hoodie bottom hem */}
          <path
            d="M 70 203 Q 110 209 150 203"
            fill="none"
            stroke="#363C4D"
            strokeWidth="2"
            strokeLinecap="round"
          />
          {/* Hoodie drawstrings */}
          <path d="M 101 153 L 99 171" stroke="#EAEFF5" strokeWidth="2.2" strokeLinecap="round" />
          <path d="M 119 153 L 121 171" stroke="#EAEFF5" strokeWidth="2.2" strokeLinecap="round" />
          <circle cx="99" cy="172" r="2.3" fill="#FFFFFF" />
          <circle cx="121" cy="172" r="2.3" fill="#FFFFFF" />
        </g>

        {/* LEFT & RIGHT ARMS */}
        {/* Left Arm */}
        <motion.g
          animate={
            prefersReducedMotion
              ? {}
              : isDancing
                ? { rotate: [-18, 16, -18] }
                : isWalking
                  ? { rotate: [12, -12, 12] }
                  : pose === 'celebrating'
                    ? { rotate: [24, 38, 24] }
                    : {}
          }
          transition={{ duration: 0.85, repeat: Infinity, ease: 'easeInOut' }}
          style={{
            transformOrigin: '76px 152px',
            transform: isHoldingLetter || isHoldingCake ? 'rotate(-36deg)' : pose === 'celebrating' ? 'rotate(34deg)' : undefined,
          }}
        >
          <path
            d="M 76 147 C 60 154, 52 174, 57 186 C 62 193, 72 189, 75 178 C 77 170, 79 160, 81 154"
            fill={`url(#${uid}-hoodie)`}
            stroke="#151820"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          {/* Cute hand peeking from sleeve */}
          <circle cx="62" cy="186" r="6.5" fill={p.skinBase} stroke="#362C2B" strokeWidth="2" />
        </motion.g>

        {/* Right Arm */}
        <motion.g
          animate={
            prefersReducedMotion
              ? {}
              : isWaving
                ? { rotate: [-28, -56, -24, -54, -28] }
                : isDancing
                  ? { rotate: [16, -18, 16] }
                  : isWalking
                    ? { rotate: [-12, 12, -12] }
                    : {}
          }
          transition={{
            duration: isWaving ? 1.3 : 0.85,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          style={{
            transformOrigin: '144px 152px',
            transform: isHoldingLetter || isHoldingCake ? 'rotate(36deg)' : undefined,
          }}
        >
          <path
            d="M 144 147 C 160 154, 168 174, 163 186 C 158 193, 148 189, 145 178 C 143 170, 141 160, 139 154"
            fill={`url(#${uid}-hoodie)`}
            stroke="#151820"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
          <circle cx="158" cy="186" r="6.5" fill={p.skinBase} stroke="#362C2B" strokeWidth="2" />
        </motion.g>

        {/* COLLAR RIBBON & GOLDEN BELL */}
        <g>
          <path
            d="M 88 144 Q 110 155 132 144"
            fill="none"
            stroke={p.ribbon}
            strokeWidth="5.5"
            strokeLinecap="round"
          />
          {/* Small collar bow */}
          <path d="M 110 150 L 101 146 L 103 154 Z" fill={p.ribbon} stroke="#4D789E" strokeWidth="1.2" />
          <path d="M 110 150 L 119 146 L 117 154 Z" fill={p.ribbon} stroke="#4D789E" strokeWidth="1.2" />
          {/* Golden Bell */}
          <circle cx="110" cy="158" r="7.5" fill={`url(#${uid}-bell)`} stroke="#8C6214" strokeWidth="1.8" />
          <ellipse cx="107.8" cy="155.5" rx="2.3" ry="1.5" fill="#FFF9D6" opacity="0.9" />
          <circle cx="110" cy="161" r="1.4" fill="#6E4B0C" />
          <line x1="110" y1="162" x2="110" y2="165" stroke="#6E4B0C" strokeWidth="1.3" strokeLinecap="round" />
        </g>

        {/* HEAD GROUP (Hood, Cat Ears, Face, Hair, Eyes) */}
        <motion.g
          animate={
            prefersReducedMotion
              ? {}
              : {
                  rotate: headTilt,
                }
          }
          transition={{ type: 'spring', stiffness: 160, damping: 16 }}
          style={{ transformOrigin: '110px 136px' }}
        >
          {/* Cat Ears on Black Hoodie */}
          <g>
            {/* Left Cat Ear */}
            <path
              d="M 54 58 C 48 30, 58 20, 82 36 Z"
              fill="#222630"
              stroke="#151820"
              strokeWidth="2.8"
              strokeLinejoin="round"
            />
            <path d="M 59 52 C 56 36, 62 31, 75 39 Z" fill={p.innerEar} opacity="0.9" />

            {/* Right Cat Ear */}
            <path
              d="M 166 58 C 172 30, 162 20, 138 36 Z"
              fill="#222630"
              stroke="#151820"
              strokeWidth="2.8"
              strokeLinejoin="round"
            />
            <path d="M 161 52 C 164 36, 158 31, 145 39 Z" fill={p.innerEar} opacity="0.9" />
          </g>

          {/* Outer Black Cat Hood Shell */}
          <path
            d="M 48 92 C 46 46, 75 30, 110 30 C 145 30, 174 46, 172 92 C 171 124, 149 144, 110 144 C 71 144, 49 124, 48 92 Z"
            fill={`url(#${uid}-hoodie)`}
            stroke="#151820"
            strokeWidth="2.8"
          />
          {/* Subtle highlight on top of hood */}
          <path
            d="M 75 40 Q 110 32 145 40"
            fill="none"
            stroke="#444B5E"
            strokeWidth="2.5"
            strokeLinecap="round"
            opacity="0.7"
          />

          {/* Face Base */}
          <path
            d="M 60 88 C 60 56, 82 44, 110 44 C 138 44, 160 56, 160 88 C 160 118, 140 137, 110 137 C 80 137, 60 118, 60 88 Z"
            fill={p.skinBase}
            stroke="#362C2B"
            strokeWidth="2.2"
          />
          {/* Soft chin shading */}
          <path
            d="M 72 121 Q 110 138 148 121 Q 134 135 110 135 Q 86 135 72 121 Z"
            fill={p.skinShadow}
            opacity="0.55"
          />

          {/* Cheek Blush */}
          <ellipse
            cx="77"
            cy="107"
            rx={isBlushing ? 14 : 11}
            ry={isBlushing ? 8 : 6}
            fill={`url(#${uid}-blush)`}
            opacity={isBlushing ? 0.95 : 0.65}
          />
          <ellipse
            cx="143"
            cy="107"
            rx={isBlushing ? 14 : 11}
            ry={isBlushing ? 8 : 6}
            fill={`url(#${uid}-blush)`}
            opacity={isBlushing ? 0.95 : 0.65}
          />
          {isBlushing && (
            <g stroke="#EB7D94" strokeWidth="1.2" strokeLinecap="round" opacity="0.65">
              <line x1="72" y1="109" x2="75" y2="105" />
              <line x1="77" y1="109" x2="80" y2="105" />
              <line x1="140" y1="109" x2="143" y2="105" />
              <line x1="145" y1="109" x2="148" y2="105" />
            </g>
          )}

          {/* EYES */}
          {isClosedEyes ? (
            <g stroke="#2B2223" strokeWidth="2.8" strokeLinecap="round" fill="none">
              <path d="M 75 94 Q 86 101 97 94" />
              <path d="M 123 94 Q 134 101 145 94" />
            </g>
          ) : isHappyArcEyes ? (
            <g stroke="#2B2223" strokeWidth="3" strokeLinecap="round" fill="none">
              <path d="M 75 97 Q 86 85 97 97" />
              <path d="M 123 97 Q 134 85 145 97" />
            </g>
          ) : (
            <g>
              {/* Left Eye */}
              <g>
                <ellipse cx="86" cy="94" rx="11.5" ry={isSurprised ? 13 : 12} fill="#FFFFFF" stroke="#241D1E" strokeWidth="2" />
                <g transform={`translate(${pupilShiftX}, 0)`}>
                  <ellipse cx="86" cy="95" rx={isSurprised ? 7.2 : 8.5} ry={isSurprised ? 8.5 : 9.8} fill={`url(#${uid}-iris)`} />
                  <circle cx="86" cy="95" r={isSurprised ? 3.5 : 4.2} fill="#141820" />
                  <circle cx="82.5" cy="90.5" r="3.2" fill="#FFFFFF" />
                  <circle cx="90" cy="99" r="1.6" fill="#FFFFFF" opacity="0.9" />
                </g>
                {/* Upper anime lash arc */}
                <path
                  d="M 73 91 Q 86 79 99 90"
                  fill="none"
                  stroke="#1E181A"
                  strokeWidth="3.2"
                  strokeLinecap="round"
                />
                {identity === 'malaika' && (
                  <path d="M 74 89 L 70 86" stroke="#1E181A" strokeWidth="2" strokeLinecap="round" />
                )}
              </g>

              {/* Right Eye */}
              <g>
                <ellipse cx="134" cy="94" rx="11.5" ry={isSurprised ? 13 : 12} fill="#FFFFFF" stroke="#241D1E" strokeWidth="2" />
                <g transform={`translate(${pupilShiftX}, 0)`}>
                  <ellipse cx="134" cy="95" rx={isSurprised ? 7.2 : 8.5} ry={isSurprised ? 8.5 : 9.8} fill={`url(#${uid}-iris)`} />
                  <circle cx="134" cy="95" r={isSurprised ? 3.5 : 4.2} fill="#141820" />
                  <circle cx="130.5" cy="90.5" r="3.2" fill="#FFFFFF" />
                  <circle cx="138" cy="99" r="1.6" fill="#FFFFFF" opacity="0.9" />
                </g>
                <path
                  d="M 121 90 Q 134 79 147 91"
                  fill="none"
                  stroke="#1E181A"
                  strokeWidth="3.2"
                  strokeLinecap="round"
                />
                {identity === 'malaika' && (
                  <path d="M 146 89 L 150 86" stroke="#1E181A" strokeWidth="2" strokeLinecap="round" />
                )}
              </g>
            </g>
          )}

          {/* EYEBROWS */}
          <g stroke={p.hairOutline} strokeWidth="2" strokeLinecap="round" fill="none">
            {isSurprised ? (
              <>
                <path d="M 77 75 Q 86 71 95 75" />
                <path d="M 125 75 Q 134 71 143 75" />
              </>
            ) : (
              <>
                <path d="M 78 78 Q 86 76 94 78" />
                <path d="M 126 78 Q 134 76 142 78" />
              </>
            )}
          </g>

          {/* MOUTH */}
          <g>
            {isSurprised ? (
              <ellipse cx="110" cy="116" rx="4.2" ry="5.2" fill="#E87A88" stroke="#362C2B" strokeWidth="1.8" />
            ) : pose === 'sleeping' ? (
              <path d="M 106 115 Q 110 118 114 115" fill="none" stroke="#4D3736" strokeWidth="2" strokeLinecap="round" />
            ) : pose === 'celebrating' || pose === 'dancing' ? (
              <path
                d="M 102 112 Q 110 124 118 112 Z"
                fill="#EE8696"
                stroke="#362C2B"
                strokeWidth="1.8"
                strokeLinejoin="round"
              />
            ) : (
              /* Cute cat-like soft smile */
              <path
                d="M 103 114 Q 106.5 118 110 114 Q 113.5 118 117 114"
                fill="none"
                stroke="#4D3736"
                strokeWidth="2.1"
                strokeLinecap="round"
              />
            )}
          </g>

          {/* HAIR BANGS & SIDE LOCKS */}
          {identity === 'malaika' ? (
            /* Malaika: Blonde / light golden bangs & side locks framing face */
            <g>
              <path
                d="M 57 88 C 56 54, 78 40, 110 40 C 142 40, 164 54, 163 88 C 159 77, 152 70, 146 82 C 142 66, 131 61, 125 79 C 119 63, 107 60, 101 80 C 94 63, 82 62, 76 80 C 70 69, 62 76, 57 88 Z"
                fill={p.hairBase}
                stroke={p.hairOutline}
                strokeWidth="2.2"
                strokeLinejoin="round"
              />
              {/* Side framing locks */}
              <path
                d="M 58 76 C 53 96, 55 120, 66 132 C 66 116, 67 99, 69 82 Z"
                fill={p.hairBase}
                stroke={p.hairOutline}
                strokeWidth="2"
                strokeLinejoin="round"
              />
              <path
                d="M 162 76 C 167 96, 165 120, 154 132 C 154 116, 153 99, 151 82 Z"
                fill={p.hairBase}
                stroke={p.hairOutline}
                strokeWidth="2"
                strokeLinejoin="round"
              />
              {/* Glossy blonde highlight arc */}
              <path
                d="M 78 56 Q 110 48 142 56"
                fill="none"
                stroke={p.hairLight}
                strokeWidth="4.5"
                strokeLinecap="round"
                opacity="0.85"
              />
            </g>
          ) : (
            /* Zayan: Messy dark brown/black spiky-soft bangs */
            <g>
              <path
                d="M 57 86 C 55 52, 78 39, 110 39 C 142 39, 165 52, 163 86 C 157 74, 150 71, 144 83 C 141 66, 129 63, 121 82 C 117 61, 104 60, 96 81 C 91 64, 79 65, 74 82 C 69 72, 62 76, 57 86 Z"
                fill={p.hairBase}
                stroke={p.hairOutline}
                strokeWidth="2.2"
                strokeLinejoin="round"
              />
              {/* Messy side tufts */}
              <path
                d="M 59 74 C 52 88, 54 106, 62 115 C 63 102, 64 90, 66 79 Z"
                fill={p.hairBase}
                stroke={p.hairOutline}
                strokeWidth="2"
                strokeLinejoin="round"
              />
              <path
                d="M 161 74 C 168 88, 166 106, 158 115 C 157 102, 156 90, 154 79 Z"
                fill={p.hairBase}
                stroke={p.hairOutline}
                strokeWidth="2"
                strokeLinejoin="round"
              />
              {/* Subtle dark hair shine */}
              <path
                d="M 79 55 Q 108 48 138 55"
                fill="none"
                stroke={p.hairLight}
                strokeWidth="3.5"
                strokeLinecap="round"
                opacity="0.75"
              />
            </g>
          )}
        </motion.g>

        {/* PROP OVERLAYS FOR SPECIFIC POSES */}
        {isHoldingLetter && (
          <motion.g
            animate={prefersReducedMotion ? {} : { y: [0, -3, 0] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
          >
            <rect
              x="82"
              y="164"
              width="56"
              height="38"
              rx="6"
              fill="#FFFFFF"
              stroke="#7CAAD3"
              strokeWidth="2"
            />
            <path d="M 83 166 L 110 185 L 137 166" fill="none" stroke="#A7CBE8" strokeWidth="2" strokeLinejoin="round" />
            {/* Tiny blue heart seal */}
            <path
              d="M 110 190 C 107 186, 102 187, 102 191 C 102 195, 110 199, 110 199 C 110 199, 118 195, 118 191 C 118 187, 113 186, 110 190 Z"
              fill="#7CAAD3"
            />
          </motion.g>
        )}

        {isHoldingCake && (
          <g>
            {/* Small birthday plate / gesture shimmer */}
            <ellipse cx="110" cy="184" rx="28" ry="6" fill="#FFFFFF" stroke="#8EB8DC" strokeWidth="1.8" />
            <rect x="93" y="164" width="34" height="19" rx="5" fill="#FFFDF9" stroke="#C9E1F5" strokeWidth="1.8" />
            <path d="M 93 171 Q 101 176 110 171 Q 119 176 127 171" fill="none" stroke="#8EB8DC" strokeWidth="2.5" />
            <line x1="110" y1="154" x2="110" y2="164" stroke="#8EB8DC" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M 110 147 C 113 151, 112 155, 110 155 C 108 155, 107 151, 110 147 Z" fill="#FFD166" />
          </g>
        )}

        {/* Surprised pop indicator */}
        {isSurprised && (
          <g transform="translate(166, 46)">
            <path d="M 0 0 L 3 -14" stroke="#5C93C4" strokeWidth="3.2" strokeLinecap="round" />
            <circle cx="-1" cy="6" r="2.2" fill="#5C93C4" />
          </g>
        )}

        {/* Sleeping Zzz indicator */}
        {pose === 'sleeping' && (
          <g fill="#6B93B8" fontFamily="DM Sans, sans-serif" fontWeight="600" fontSize="14">
            <text x="158" y="66">z</text>
            <text x="170" y="54" fontSize="11" opacity="0.8">
              z
            </text>
          </g>
        )}
      </svg>
    </motion.div>
  );
};

/**
 * Dedicated intertwined Hugging Couple illustration preserving exact Malaika & Zayan consistency
 * for Chapter 07 ("One Last Hug").
 */
export const HuggingCouple: React.FC<{ size?: number; className?: string }> = ({
  size = 270,
  className = '',
}) => {
  const prefersReducedMotion = useReducedMotion();

  return (
    <motion.div
      animate={prefersReducedMotion ? {} : { scale: [1, 1.02, 1], y: [0, -3, 0] }}
      transition={{ duration: 3.6, repeat: Infinity, ease: 'easeInOut' }}
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size * 0.92 }}
      aria-label="Malaika and Zayan sharing a warm hug"
    >
      <svg viewBox="0 0 300 265" className="w-full h-full chibi-sticker overflow-visible">
        <defs>
          <linearGradient id="hug-hoodie" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2F3441" />
            <stop offset="100%" stopColor="#1B1E27" />
          </linearGradient>
          <linearGradient id="hug-bell" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FFE68C" />
            <stop offset="100%" stopColor="#D69E24" />
          </linearGradient>
        </defs>

        {/* Ground shadow */}
        <ellipse cx="150" cy="242" rx="76" ry="11" fill="rgba(64, 90, 115, 0.14)" />

        {/* Malaika's Tail (left) */}
        <g className={prefersReducedMotion ? '' : 'animate-tail-sway'}>
          <path
            d="M 85 204 C 54 202, 40 175, 50 154 C 56 144, 67 149, 62 160 C 57 172, 68 190, 88 192 Z"
            fill="#222630"
            stroke="#151820"
            strokeWidth="2.4"
          />
        </g>

        {/* Zayan's Tail (right) */}
        <g className={prefersReducedMotion ? '' : 'animate-tail-sway'}>
          <path
            d="M 215 204 C 246 202, 260 175, 250 154 C 244 144, 233 149, 238 160 C 243 172, 232 190, 212 192 Z"
            fill="#222630"
            stroke="#151820"
            strokeWidth="2.4"
          />
        </g>

        {/* Legs for both */}
        <rect x="92" y="206" width="14" height="22" rx="6" fill="#FFE8DD" stroke="#362C2B" strokeWidth="2" />
        <rect x="116" y="206" width="14" height="22" rx="6" fill="#FFE8DD" stroke="#362C2B" strokeWidth="2" />
        <ellipse cx="99" cy="229" rx="10" ry="5.5" fill="#2C3240" stroke="#181B24" strokeWidth="2" />
        <ellipse cx="123" cy="229" rx="10" ry="5.5" fill="#2C3240" stroke="#181B24" strokeWidth="2" />

        <rect x="168" y="206" width="14" height="22" rx="6" fill="#FCE3D6" stroke="#362C2B" strokeWidth="2" />
        <rect x="192" y="206" width="14" height="22" rx="6" fill="#FCE3D6" stroke="#362C2B" strokeWidth="2" />
        <ellipse cx="175" cy="229" rx="10" ry="5.5" fill="#2C3240" stroke="#181B24" strokeWidth="2" />
        <ellipse cx="199" cy="229" rx="10" ry="5.5" fill="#2C3240" stroke="#181B24" strokeWidth="2" />

        {/* Combined cozy hugging torsos */}
        <path
          d="M 76 150 C 68 175, 68 202, 76 212 C 102 217, 134 217, 150 212 C 166 217, 198 217, 224 212 C 232 202, 232 175, 224 150 Z"
          fill="url(#hug-hoodie)"
          stroke="#151820"
          strokeWidth="2.6"
          strokeLinejoin="round"
        />

        {/* Embracing Arms wrapped around each other */}
        <path
          d="M 85 164 C 110 158, 138 164, 166 174 C 174 177, 174 188, 162 187 C 138 183, 110 180, 88 182"
          fill="#2B303D"
          stroke="#151820"
          strokeWidth="2.4"
          strokeLinecap="round"
        />
        <circle cx="168" cy="181" r="6" fill="#FFE8DD" stroke="#362C2B" strokeWidth="1.8" />

        <path
          d="M 215 164 C 190 158, 162 164, 134 174 C 126 177, 126 188, 138 187 C 162 183, 190 180, 212 182"
          fill="#262A36"
          stroke="#151820"
          strokeWidth="2.4"
          strokeLinecap="round"
        />
        <circle cx="132" cy="181" r="6" fill="#FCE3D6" stroke="#362C2B" strokeWidth="1.8" />

        {/* Golden Bells */}
        <circle cx="107" cy="158" r="6.5" fill="url(#hug-bell)" stroke="#8C6214" strokeWidth="1.6" />
        <circle cx="193" cy="158" r="6.5" fill="url(#hug-bell)" stroke="#8C6214" strokeWidth="1.6" />

        {/* MALAIKA HEAD (Left, tilted warmly inward) */}
        <g transform="translate(56, 26) rotate(7 60 72)">
          <path d="M 18 52 C 12 26, 22 18, 44 33 Z" fill="#222630" stroke="#151820" strokeWidth="2.6" />
          <path d="M 22 47 C 20 33, 25 28, 38 35 Z" fill="#F4BAC7" />
          <path d="M 102 52 C 108 26, 98 18, 76 33 Z" fill="#222630" stroke="#151820" strokeWidth="2.6" />
          <path d="M 98 47 C 100 33, 95 28, 82 35 Z" fill="#F4BAC7" />

          <path
            d="M 14 82 C 12 42, 34 28, 60 28 C 86 28, 108 42, 106 82 C 105 112, 86 128, 60 128 C 34 128, 15 112, 14 82 Z"
            fill="url(#hug-hoodie)"
            stroke="#151820"
            strokeWidth="2.6"
          />
          <path
            d="M 22 79 C 22 52, 38 42, 60 42 C 82 42, 98 52, 98 79 C 98 104, 82 121, 60 121 C 38 121, 22 104, 22 79 Z"
            fill="#FFE8DD"
            stroke="#362C2B"
            strokeWidth="2"
          />
          <ellipse cx="36" cy="94" rx="10" ry="5.5" fill="#F79FB0" opacity="0.8" />
          <ellipse cx="84" cy="94" rx="10" ry="5.5" fill="#F79FB0" opacity="0.8" />
          {/* Closed peaceful eyes */}
          <path d="M 35 84 Q 43 90 51 84" fill="none" stroke="#2B2223" strokeWidth="2.6" strokeLinecap="round" />
          <path d="M 69 84 Q 77 90 85 84" fill="none" stroke="#2B2223" strokeWidth="2.6" strokeLinecap="round" />
          <path d="M 55 100 Q 60 105 65 100" fill="none" stroke="#4D3736" strokeWidth="2" strokeLinecap="round" />
          {/* Blonde bangs */}
          <path
            d="M 20 79 C 19 49, 36 38, 60 38 C 84 38, 101 49, 100 79 C 95 69, 89 65, 84 76 C 80 62, 70 59, 64 74 C 58 60, 48 60, 43 75 C 37 64, 28 67, 20 79 Z"
            fill="#F3D27A"
            stroke="#7F612B"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <path d="M 38 52 Q 60 45 82 52" fill="none" stroke="#FCE9AC" strokeWidth="3.5" strokeLinecap="round" />
        </g>

        {/* ZAYAN HEAD (Right, tilted warmly inward) */}
        <g transform="translate(124, 24) rotate(-7 60 72)">
          <path d="M 18 52 C 12 26, 22 18, 44 33 Z" fill="#222630" stroke="#151820" strokeWidth="2.6" />
          <path d="M 22 47 C 20 33, 25 28, 38 35 Z" fill="#E7B0BE" />
          <path d="M 102 52 C 108 26, 98 18, 76 33 Z" fill="#222630" stroke="#151820" strokeWidth="2.6" />
          <path d="M 98 47 C 100 33, 95 28, 82 35 Z" fill="#E7B0BE" />

          <path
            d="M 14 82 C 12 42, 34 28, 60 28 C 86 28, 108 42, 106 82 C 105 112, 86 128, 60 128 C 34 128, 15 112, 14 82 Z"
            fill="url(#hug-hoodie)"
            stroke="#151820"
            strokeWidth="2.6"
          />
          <path
            d="M 22 79 C 22 52, 38 42, 60 42 C 82 42, 98 52, 98 79 C 98 104, 82 121, 60 121 C 38 121, 22 104, 22 79 Z"
            fill="#FCE3D6"
            stroke="#362C2B"
            strokeWidth="2"
          />
          <ellipse cx="36" cy="94" rx="10" ry="5.5" fill="#F596A8" opacity="0.8" />
          <ellipse cx="84" cy="94" rx="10" ry="5.5" fill="#F596A8" opacity="0.8" />
          {/* Closed peaceful eyes */}
          <path d="M 35 84 Q 43 90 51 84" fill="none" stroke="#2B2223" strokeWidth="2.6" strokeLinecap="round" />
          <path d="M 69 84 Q 77 90 85 84" fill="none" stroke="#2B2223" strokeWidth="2.6" strokeLinecap="round" />
          <path d="M 55 100 Q 60 105 65 100" fill="none" stroke="#4D3736" strokeWidth="2" strokeLinecap="round" />
          {/* Messy dark bangs */}
          <path
            d="M 20 79 C 19 48, 36 37, 60 37 C 84 37, 101 48, 100 79 C 94 68, 88 66, 83 77 C 79 61, 69 59, 63 75 C 58 58, 46 58, 41 75 C 36 65, 27 67, 20 79 Z"
            fill="#2A2120"
            stroke="#140E0E"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <path d="M 38 51 Q 60 44 82 51" fill="none" stroke="#463836" strokeWidth="3" strokeLinecap="round" />
        </g>
      </svg>
    </motion.div>
  );
};
