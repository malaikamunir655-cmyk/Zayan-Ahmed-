import React from 'react';
import { ChibiBase } from './ChibiBase';
import { CharacterPose, LookDirection } from '../../types/story';

interface CharacterProps {
  pose?: CharacterPose;
  lookDirection?: LookDirection;
  facing?: 'left' | 'right';
  size?: number;
  className?: string;
  onTap?: () => void;
}

export const ZayanCharacter: React.FC<CharacterProps> = (props) => {
  return (
    <ChibiBase
      identity="zayan"
      ariaLabel="Zayan chibi character wearing a matching black cat hoodie"
      {...props}
    />
  );
};
