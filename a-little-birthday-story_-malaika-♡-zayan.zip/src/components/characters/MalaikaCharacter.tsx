import React from 'react';
import { ChibiBase } from './ChibiBase';
import { CharacterPose, LookDirection } from '../../types/story';

interface CharacterProps {
  pose?: CharacterPose;
  lookDirection?: LookDirection;
  facing?: 'left' | 'right';
  size?: number;
  className?: string;
  onTap?: () => void;
}

export const MalaikaCharacter: React.FC<CharacterProps> = (props) => {
  return (
    <ChibiBase
      identity="malaika"
      ariaLabel="Malaika chibi character wearing a black cat hoodie"
      {...props}
    />
  );
};
