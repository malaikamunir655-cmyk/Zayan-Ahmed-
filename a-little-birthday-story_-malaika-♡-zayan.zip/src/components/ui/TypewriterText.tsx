import React, { useEffect, useState } from 'react';
import { useReducedMotion } from 'motion/react';

interface TypewriterTextProps {
  text: string;
  speedMs?: number;
  startDelayMs?: number;
  onComplete?: () => void;
  className?: string;
}

export const TypewriterText: React.FC<TypewriterTextProps> = ({
  text,
  speedMs = 34,
  startDelayMs = 0,
  onComplete,
  className = '',
}) => {
  const prefersReducedMotion = useReducedMotion();
  const [displayedCount, setDisplayedCount] = useState(prefersReducedMotion ? text.length : 0);
  const onCompleteRef = React.useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    if (prefersReducedMotion) {
      setDisplayedCount(text.length);
      onCompleteRef.current?.();
      return;
    }

    setDisplayedCount(0);
    let intervalId: number | undefined;
    const delayId = window.setTimeout(() => {
      let current = 0;
      intervalId = window.setInterval(() => {
        current += 1;
        setDisplayedCount(current);
        if (current >= text.length) {
          if (intervalId) window.clearInterval(intervalId);
          onCompleteRef.current?.();
        }
      }, speedMs);
    }, startDelayMs);

    return () => {
      window.clearTimeout(delayId);
      if (intervalId) window.clearInterval(intervalId);
    };
  }, [text, speedMs, startDelayMs, prefersReducedMotion]);

  return (
    <span className={`whitespace-pre-line ${className}`}>
      {text.slice(0, displayedCount)}
    </span>
  );
};
