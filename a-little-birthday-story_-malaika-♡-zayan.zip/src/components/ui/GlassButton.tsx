import React from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { soundEngine } from '../../utils/soundEngine';

interface GlassButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'subtle';
  silent?: boolean;
}

export const GlassButton: React.FC<GlassButtonProps> = ({
  children,
  className = '',
  variant = 'primary',
  silent = false,
  onClick,
  ...rest
}) => {
  const prefersReducedMotion = useReducedMotion();

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!silent) {
      soundEngine.playClick();
    }
    onClick?.(e);
  };

  return (
    <motion.button
      type="button"
      whileHover={prefersReducedMotion ? undefined : { scale: 1.03, y: -1 }}
      whileTap={prefersReducedMotion ? undefined : { scale: 0.96 }}
      transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
      onClick={handleClick}
      className={`
        glass-button inline-flex items-center justify-center gap-2
        min-h-[48px] px-7 py-3 rounded-full
        font-sans text-[15px] font-medium tracking-wide whitespace-nowrap shrink-0
        text-[#2E4861] transition-all duration-200 cursor-pointer
        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5C93C4] focus-visible:ring-offset-2 focus-visible:ring-offset-[#EFF7FC]
        disabled:opacity-50 disabled:cursor-not-allowed
        ${variant === 'subtle' ? 'bg-white/40 min-h-[44px] px-4 py-2 text-sm' : ''}
        ${className}
      `}
      {...(rest as Record<string, unknown>)}
    >
      {children}
    </motion.button>
  );
};
