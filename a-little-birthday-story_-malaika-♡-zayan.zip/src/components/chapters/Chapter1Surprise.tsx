import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MalaikaCharacter } from '../characters/MalaikaCharacter';
import { FloatingBalloons } from '../environment/FloatingBalloons';
import { AmbientParticles } from '../environment/AmbientParticles';
import { TypewriterText } from '../ui/TypewriterText';
import { GlassButton } from '../ui/GlassButton';
import { LookDirection } from '../../types/story';
import { soundEngine } from '../../utils/soundEngine';

interface Chapter1Props {
  onNext: () => void;
}

export const Chapter1Surprise: React.FC<Chapter1Props> = ({ onNext }) => {
  const prefersReducedMotion = useReducedMotion();
  const [peekedIn, setPeekedIn] = useState(prefersReducedMotion ? true : false);
  const [lookDir, setLookDir] = useState<LookDirection>('center');
  const [waving, setWaving] = useState(false);
  const [showText, setShowText] = useState(prefersReducedMotion ? true : false);
  const [showButton, setShowButton] = useState(prefersReducedMotion ? true : false);
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    if (prefersReducedMotion) return;

    const t1 = window.setTimeout(() => setPeekedIn(true), 650);
    const t2 = window.setTimeout(() => setLookDir('left'), 1350);
    const t3 = window.setTimeout(() => setLookDir('right'), 1850);
    const t4 = window.setTimeout(() => {
      setLookDir('center');
      setWaving(true);
    }, 2350);
    const t5 = window.setTimeout(() => setShowText(true), 2750);

    return () => {
      [t1, t2, t3, t4, t5].forEach((t) => window.clearTimeout(t));
    };
  }, [prefersReducedMotion]);

  const handleBegin = () => {
    if (exiting) return;
    soundEngine.startMusic();
    soundEngine.playChime();
    setWaving(true);
    setExiting(true);
    window.setTimeout(() => {
      onNext();
    }, prefersReducedMotion ? 180 : 950);
  };

  return (
    <section className="relative w-full min-h-[calc(100dvh-76px)] flex flex-col items-center justify-center px-5 py-6 text-center">
      <FloatingBalloons dispersed={exiting} />
      <AmbientParticles variant="sparkles" count={15} />

      <div className="relative z-10 w-full max-w-xl mx-auto flex flex-col items-center justify-center gap-6">
        {/* Malaika peeking up & waving */}
        <motion.div
          initial={prefersReducedMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 120 }}
          animate={
            exiting
              ? { y: -8, scale: 1.05 }
              : peekedIn
                ? { opacity: 1, y: 0 }
                : { opacity: 0, y: 120 }
          }
          transition={{ duration: 1.0, ease: [0.16, 1, 0.3, 1] }}
          className="flex items-center justify-center"
        >
          <MalaikaCharacter
            pose={exiting ? 'celebrating' : waving ? 'waving' : 'peeking'}
            lookDirection={lookDir}
            size={182}
            onTap={() => soundEngine.playChime()}
          />
        </motion.div>

        {/* Story Dialogue */}
        <div className="min-h-[88px] flex flex-col items-center justify-center">
          {showText && (
            <h1 className="font-serif text-[28px] sm:text-[38px] font-semibold leading-[1.28] text-[#2B435B] tracking-tight text-balance">
              <TypewriterText
                text={'Hey Zayan...\nSomeone has a little surprise for you.'}
                speedMs={34}
                onComplete={() => setShowButton(true)}
              />
            </h1>
          )}
        </div>

        {/* Interactive CTA Button */}
        <div className="min-h-[56px] flex items-center justify-center">
          {showButton && (
            <motion.div
              initial={prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease: 'easeOut' }}
            >
              <GlassButton onClick={handleBegin} disabled={exiting}>
                Should we begin? ♡
              </GlassButton>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
};
