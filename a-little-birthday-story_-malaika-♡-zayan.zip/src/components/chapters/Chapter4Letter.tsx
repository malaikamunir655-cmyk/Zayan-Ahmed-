import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MalaikaCharacter } from '../characters/MalaikaCharacter';
import { AmbientParticles } from '../environment/AmbientParticles';
import { LetterAnimation } from '../story/LetterAnimation';
import { GlassButton } from '../ui/GlassButton';
import { soundEngine } from '../../utils/soundEngine';

interface Chapter4Props {
  onNext: () => void;
}

export const Chapter4Letter: React.FC<Chapter4Props> = ({ onNext }) => {
  const [letterOpened, setLetterOpened] = useState(false);
  const [letterFinished, setLetterFinished] = useState(false);

  return (
    <section className="relative w-full min-h-[calc(100dvh-76px)] flex flex-col items-center justify-center px-5 py-6 text-center">
      <AmbientParticles variant="sparkles" count={9} />

      <div className="relative z-10 w-full max-w-2xl mx-auto flex flex-col items-center gap-5">
        {/* Malaika holding the sealed letter (or smiling warmly once opened) */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65 }}
          className="flex flex-col items-center"
        >
          <MalaikaCharacter
            pose={letterOpened ? 'blushing' : 'holding-letter'}
            lookDirection="center"
            size={letterOpened ? 132 : 165}
            className={letterOpened ? 'w-[116px] sm:w-[138px] transition-all duration-500' : 'w-[148px] sm:w-[172px]'}
            onTap={() => soundEngine.playChime()}
          />
        </motion.div>

        {/* Interactive Envelope -> Unfolding Handwritten Letter */}
        <LetterAnimation
          onOpened={() => setLetterOpened(true)}
          onFinishReveal={() => setLetterFinished(true)}
        />

        {/* Continue button once letter finishes revealing */}
        <div className="min-h-[56px] flex items-center justify-center">
          {letterFinished && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
            >
              <GlassButton onClick={onNext}>Continue ♡</GlassButton>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
};
