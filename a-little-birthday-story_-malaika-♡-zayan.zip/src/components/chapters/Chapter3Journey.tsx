import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MalaikaCharacter } from '../characters/MalaikaCharacter';
import { ZayanCharacter } from '../characters/ZayanCharacter';
import { DreamySkyScene } from '../environment/DreamySkyScene';
import { AmbientParticles } from '../environment/AmbientParticles';
import { GlassButton } from '../ui/GlassButton';
import { soundEngine } from '../../utils/soundEngine';

interface Chapter3Props {
  onNext: () => void;
}

export const Chapter3Journey: React.FC<Chapter3Props> = ({ onNext }) => {
  const prefersReducedMotion = useReducedMotion();
  const [settled, setSettled] = useState(prefersReducedMotion ? true : false);
  const [showText, setShowText] = useState(prefersReducedMotion ? true : false);
  const [showButton, setShowButton] = useState(prefersReducedMotion ? true : false);

  useEffect(() => {
    if (prefersReducedMotion) return;

    const t1 = window.setTimeout(() => setSettled(true), 1750);
    const t2 = window.setTimeout(() => setShowText(true), 2050);
    const t3 = window.setTimeout(() => setShowButton(true), 2850);

    return () => {
      [t1, t2, t3].forEach((t) => window.clearTimeout(t));
    };
  }, [prefersReducedMotion]);

  return (
    <section className="relative w-full min-h-[calc(100dvh-76px)] flex flex-col items-center justify-center px-5 py-6 text-center">
      <DreamySkyScene />
      <AmbientParticles variant="sparkles" count={10} />

      <div className="relative z-10 w-full max-w-2xl mx-auto flex flex-col items-center gap-6">
        {/* Characters walking side-by-side onto the dreamy meadow */}
        <motion.div
          initial={prefersReducedMotion ? { x: 0, opacity: 1 } : { x: -130, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 1.7, ease: [0.22, 1, 0.36, 1] }}
          className="flex items-end justify-center gap-1 sm:gap-5 min-h-[205px] sm:min-h-[240px]"
        >
          <MalaikaCharacter
            pose={settled ? 'standing' : 'walking'}
            lookDirection="right"
            size={158}
            className="w-[136px] sm:w-[168px]"
            onTap={() => soundEngine.playChime()}
          />
          <ZayanCharacter
            pose={settled ? 'standing' : 'walking'}
            lookDirection="left"
            size={158}
            className="w-[136px] sm:w-[168px]"
            onTap={() => soundEngine.playChime()}
          />
        </motion.div>

        {/* Text Reveal */}
        <div className="min-h-[124px] flex flex-col items-center justify-center max-w-lg px-2">
          {showText && (
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65 }}
              className="space-y-3"
            >
              <h2 className="font-serif text-[26px] sm:text-[34px] font-semibold leading-[1.28] text-[#2B435B] text-balance">
                Today, forget about everything else for a little while.
              </h2>
              <p className="font-sans text-[15px] sm:text-[17px] text-[#4C6882] leading-relaxed text-balance">
                It&apos;s your day, Zayan. So just smile, relax and enjoy every little moment.
              </p>
            </motion.div>
          )}
        </div>

        <div className="min-h-[56px] flex items-center justify-center">
          {showButton && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
            >
              <GlassButton onClick={onNext}>There&apos;s more waiting for you ♡</GlassButton>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
};
