import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MalaikaCharacter } from '../characters/MalaikaCharacter';
import { ZayanCharacter } from '../characters/ZayanCharacter';
import { BirthdayCake } from '../story/BirthdayCake';
import { AmbientParticles } from '../environment/AmbientParticles';
import { ConfettiBurst } from '../environment/ConfettiBurst';
import { GlassButton } from '../ui/GlassButton';
import { soundEngine } from '../../utils/soundEngine';

interface Chapter6Props {
  onNext: () => void;
}

export const Chapter6Wish: React.FC<Chapter6Props> = ({ onNext }) => {
  const prefersReducedMotion = useReducedMotion();
  const [cakeVisible, setCakeVisible] = useState(prefersReducedMotion ? true : false);
  const [litCandles, setLitCandles] = useState(prefersReducedMotion ? 3 : 0);
  const [showPrompt, setShowPrompt] = useState(prefersReducedMotion ? true : false);
  const [blownOut, setBlownOut] = useState(false);
  const [showAfterMessage, setShowAfterMessage] = useState(false);

  useEffect(() => {
    if (prefersReducedMotion) return;

    const t1 = window.setTimeout(() => setCakeVisible(true), 250);
    const t2 = window.setTimeout(() => setLitCandles(1), 950);
    const t3 = window.setTimeout(() => setLitCandles(2), 1350);
    const t4 = window.setTimeout(() => setLitCandles(3), 1750);
    const t5 = window.setTimeout(() => setShowPrompt(true), 2200);

    return () => {
      [t1, t2, t3, t4, t5].forEach((t) => window.clearTimeout(t));
    };
  }, [prefersReducedMotion]);

  const handleBlowCandles = () => {
    if (blownOut) return;
    setBlownOut(true);
    soundEngine.playCandleBlow();
    window.setTimeout(() => {
      setShowAfterMessage(true);
    }, prefersReducedMotion ? 200 : 1050);
  };

  return (
    <section className="relative w-full min-h-[calc(100dvh-76px)] flex flex-col items-center justify-center px-5 py-6 text-center">
      <AmbientParticles variant="sparkles" count={14} />
      <ConfettiBurst active={blownOut} />

      <div className="relative z-10 w-full max-w-2xl mx-auto flex flex-col items-center gap-5">
        {/* Stage: Malaika presenting cake, Cake in center, Zayan sitting excitedly */}
        <div className="relative w-full flex items-end justify-center gap-0 sm:gap-3 min-h-[215px] sm:min-h-[250px]">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            className="z-10"
          >
            <MalaikaCharacter
              pose={blownOut ? 'celebrating' : 'holding-cake'}
              lookDirection="right"
              size={142}
              className="w-[106px] sm:w-[148px]"
              onTap={() => soundEngine.playChime()}
            />
          </motion.div>

          {/* Center Cake rising from bottom */}
          <motion.div
            initial={prefersReducedMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 70 }}
            animate={cakeVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: 70 }}
            transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
            className="z-20 -mx-3 sm:mx-0 pb-2"
          >
            <BirthdayCake litCandles={litCandles} blownOut={blownOut} />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            className="z-10"
          >
            <ZayanCharacter
              pose={blownOut ? 'celebrating' : 'sitting'}
              lookDirection="left"
              size={142}
              className="w-[106px] sm:w-[148px]"
              onTap={() => soundEngine.playChime()}
            />
          </motion.div>
        </div>

        {/* Text & Interactive Sequence */}
        <div className="min-h-[120px] flex flex-col items-center justify-center max-w-lg px-2">
          {!blownOut && showPrompt && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55 }}
              className="space-y-2"
            >
              <h2 className="font-serif text-[27px] sm:text-[35px] font-semibold leading-[1.25] text-[#2B435B] text-balance">
                Okay birthday boy!
              </h2>
              <p className="font-sans text-[15px] sm:text-[17px] text-[#4C6882] leading-relaxed">
                Close your eyes, make a wish and get ready...
              </p>
            </motion.div>
          )}

          {showAfterMessage && (
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65 }}
              className="space-y-3"
            >
              <h2 className="font-serif text-[26px] sm:text-[34px] font-semibold leading-[1.28] text-[#2B435B] text-balance">
                I hope this year surprises you in the most beautiful ways.
              </h2>
              <p className="font-sans text-[15px] sm:text-[17px] text-[#4C6882] leading-relaxed text-balance">
                May all the things you&apos;ve been quietly wishing for find their way to you.
              </p>
            </motion.div>
          )}
        </div>

        {/* Interactive Button */}
        <div className="min-h-[56px] flex items-center justify-center">
          {!blownOut && showPrompt && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
            >
              <GlassButton onClick={handleBlowCandles} silent>
                Blow the candles! 🎂
              </GlassButton>
            </motion.div>
          )}

          {showAfterMessage && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.25 }}
            >
              <GlassButton onClick={onNext}>Continue ♡</GlassButton>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
};
