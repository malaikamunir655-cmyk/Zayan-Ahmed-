import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MalaikaCharacter } from '../characters/MalaikaCharacter';
import { ZayanCharacter } from '../characters/ZayanCharacter';
import { AmbientParticles } from '../environment/AmbientParticles';
import { GlassButton } from '../ui/GlassButton';
import { soundEngine } from '../../utils/soundEngine';

interface Chapter5Props {
  onNext: () => void;
}

export const Chapter5Special: React.FC<Chapter5Props> = ({ onNext }) => {
  const prefersReducedMotion = useReducedMotion();
  const [malaikaBlush, setMalaikaBlush] = useState(prefersReducedMotion ? true : false);
  const [zayanReact, setZayanReact] = useState(prefersReducedMotion ? true : false);
  const [showText, setShowText] = useState(prefersReducedMotion ? true : false);
  const [showButton, setShowButton] = useState(prefersReducedMotion ? true : false);

  useEffect(() => {
    if (prefersReducedMotion) return;

    const t1 = window.setTimeout(() => setMalaikaBlush(true), 650);
    const t2 = window.setTimeout(() => setZayanReact(true), 1200);
    const t3 = window.setTimeout(() => setShowText(true), 1650);
    const t4 = window.setTimeout(() => setShowButton(true), 2900);

    return () => {
      [t1, t2, t3, t4].forEach((t) => window.clearTimeout(t));
    };
  }, [prefersReducedMotion]);

  return (
    <section className="relative w-full min-h-[calc(100dvh-76px)] flex flex-col items-center justify-center px-5 py-6 text-center">
      {malaikaBlush && <AmbientParticles variant="hearts" count={11} />}

      <div className="relative z-10 w-full max-w-2xl mx-auto flex flex-col items-center gap-6">
        {/* Malaika & Zayan standing closely together */}
        <div className="relative flex items-end justify-center gap-1 sm:gap-5 min-h-[205px] sm:min-h-[235px]">
          <motion.div
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.65 }}
          >
            <MalaikaCharacter
              pose={malaikaBlush ? 'blushing' : 'standing'}
              lookDirection="right"
              size={158}
              className="w-[136px] sm:w-[168px]"
              onTap={() => soundEngine.playChime()}
            />
          </motion.div>

          {/* Subtle central floating heart */}
          {malaikaBlush && !prefersReducedMotion && (
            <motion.div
              initial={{ opacity: 0, y: 12, scale: 0.6 }}
              animate={{ opacity: [0, 0.9, 0], y: [-12, -48], scale: [0.7, 1.1, 0.9] }}
              transition={{ duration: 2.8, repeat: Infinity, ease: 'easeOut' }}
              className="absolute left-1/2 -translate-x-1/2 bottom-[130px] pointer-events-none"
              aria-hidden="true"
            >
              <svg width="24" height="24" viewBox="0 0 24 24">
                <path
                  d="M12 21C12 21 3 14.8 3 8.8C3 5.8 5.4 3.5 8.2 3.5C9.9 3.5 11.4 4.4 12 5.7C12.6 4.4 14.1 3.5 15.8 3.5C18.6 3.5 21 5.8 21 8.8C21 14.8 12 21 12 21Z"
                  fill="#F3A7B8"
                />
              </svg>
            </motion.div>
          )}

          <motion.div
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.65 }}
          >
            <ZayanCharacter
              pose={zayanReact ? 'blushing' : 'standing'}
              lookDirection="left"
              size={158}
              className="w-[136px] sm:w-[168px]"
              onTap={() => soundEngine.playChime()}
            />
          </motion.div>
        </div>

        {/* Gentle text reveal */}
        <div className="min-h-[155px] flex flex-col items-center justify-center max-w-lg px-2">
          {showText && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="space-y-3"
            >
              <h2 className="font-serif text-[26px] sm:text-[33px] font-semibold leading-[1.28] text-[#2B435B] text-balance">
                And Zayan, don&apos;t ever underestimate how special you are.
              </h2>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.7, delay: 0.35 }}
                className="font-sans text-[15px] sm:text-[17px] text-[#4C6882] leading-relaxed text-balance"
              >
                Your presence matters more than you probably realise. I hope you never lose that
                little spark that makes you YOU.
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.7, delay: 0.75 }}
                className="font-sans text-[15px] sm:text-[17px] font-medium text-[#354E66]"
              >
                Stay happy, stay weird and keep being yourself. ♡
              </motion.p>
            </motion.div>
          )}
        </div>

        <div className="min-h-[56px] flex items-center justify-center">
          {showButton && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
            >
              <GlassButton onClick={onNext}>One more surprise!</GlassButton>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
};
