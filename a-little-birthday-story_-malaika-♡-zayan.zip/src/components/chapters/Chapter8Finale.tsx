import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MalaikaCharacter } from '../characters/MalaikaCharacter';
import { ZayanCharacter } from '../characters/ZayanCharacter';
import { FinalCelebration } from '../story/FinalCelebration';
import { GlassCard } from '../ui/GlassCard';
import { GlassButton } from '../ui/GlassButton';
import { soundEngine } from '../../utils/soundEngine';

interface Chapter8Props {
  onReplay: () => void;
}

export const Chapter8Finale: React.FC<Chapter8Props> = ({ onReplay }) => {
  const prefersReducedMotion = useReducedMotion();
  const [showMessage, setShowMessage] = useState(prefersReducedMotion ? true : false);

  useEffect(() => {
    soundEngine.setFinaleMode(true);
    soundEngine.playFinaleSparkle();

    if (!prefersReducedMotion) {
      const t = window.setTimeout(() => setShowMessage(true), 650);
      return () => {
        window.clearTimeout(t);
        soundEngine.setFinaleMode(false);
      };
    }

    return () => {
      soundEngine.setFinaleMode(false);
    };
  }, [prefersReducedMotion]);

  return (
    <section className="relative w-full min-h-[calc(100dvh-76px)] flex flex-col items-center justify-center px-5 py-8 text-center">
      <FinalCelebration />

      <div className="relative z-10 w-full max-w-2xl mx-auto flex flex-col items-center gap-5">
        {/* Dancing Malaika & Zayan */}
        <motion.div
          initial={prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
          className="flex items-end justify-center gap-2 sm:gap-8 min-h-[185px] sm:min-h-[215px]"
        >
          <MalaikaCharacter
            pose="dancing"
            lookDirection="right"
            size={156}
            className="w-[132px] sm:w-[164px]"
            onTap={() => soundEngine.playFinaleSparkle()}
          />
          <ZayanCharacter
            pose="dancing"
            lookDirection="left"
            size={156}
            className="w-[132px] sm:w-[164px]"
            onTap={() => soundEngine.playFinaleSparkle()}
          />
        </motion.div>

        {/* Grand Finale Heading & Message */}
        {showMessage && (
          <motion.div
            initial={prefersReducedMotion ? { opacity: 1 } : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-xl space-y-5"
          >
            <h1 className="font-serif text-[32px] sm:text-[46px] font-bold leading-[1.16] text-[#284057] text-balance">
              Happiest Birthday, Zayan! ♡
            </h1>

            <GlassCard className="bg-white/55 border-white/80 text-center space-y-4 px-5 py-6 sm:px-8 sm:py-7">
              <p className="font-sans text-[15px] sm:text-[16.5px] leading-[1.68] text-[#354E66] text-balance">
                May your days be full of happiness, your heart full of peace, and your life full of
                beautiful surprises. I hope you achieve everything you&apos;ve been working towards.
                Keep smiling, keep growing, and never lose the little things that make you who you
                are. You deserve all the good things life has to offer.
              </p>

              <p className="font-sans text-[16px] sm:text-[17px] font-semibold text-[#2B435B]">
                Have the happiest birthday!
              </p>

              <div className="pt-3 border-t border-[#C9E1F5]/70 flex flex-col items-center gap-1">
                <p className="font-hand text-[26px] sm:text-[30px] leading-tight text-[#354E66]">
                  With lots of love,
                </p>
                <p className="font-hand text-[28px] sm:text-[32px] font-semibold text-[#4D7FA8]">
                  Malaika ♡
                </p>
              </div>
            </GlassCard>

            <div className="flex flex-col items-center gap-4 pt-1">
              <div className="inline-flex items-center gap-2 text-xs sm:text-sm text-[#58748E]">
                <span>Made with love, just for you.</span>
                <motion.svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  animate={prefersReducedMotion ? {} : { scale: [1, 1.22, 1] }}
                  transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
                  aria-hidden="true"
                >
                  <path
                    d="M12 21C12 21 3 14.8 3 8.8C3 5.8 5.4 3.5 8.2 3.5C9.9 3.5 11.4 4.4 12 5.7C12.6 4.4 14.1 3.5 15.8 3.5C18.6 3.5 21 5.8 21 8.8C21 14.8 12 21 12 21Z"
                    fill="#7CAAD3"
                  />
                </motion.svg>
              </div>

              <GlassButton onClick={onReplay}>Read our little story again ↺</GlassButton>
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
};
