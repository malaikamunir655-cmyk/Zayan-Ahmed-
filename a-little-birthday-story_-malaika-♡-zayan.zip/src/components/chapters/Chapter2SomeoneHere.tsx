import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { MalaikaCharacter } from '../characters/MalaikaCharacter';
import { ZayanCharacter } from '../characters/ZayanCharacter';
import { AmbientParticles } from '../environment/AmbientParticles';
import { GlassButton } from '../ui/GlassButton';
import { CharacterPose, LookDirection } from '../../types/story';
import { soundEngine } from '../../utils/soundEngine';

interface Chapter2Props {
  onNext: () => void;
}

export const Chapter2SomeoneHere: React.FC<Chapter2Props> = ({ onNext }) => {
  const prefersReducedMotion = useReducedMotion();
  const [malaikaLook, setMalaikaLook] = useState<LookDirection>('right');
  const [malaikaPose, setMalaikaPose] = useState<CharacterPose>('standing');
  const [zayanEntered, setZayanEntered] = useState(prefersReducedMotion ? true : false);
  const [zayanPose, setZayanPose] = useState<CharacterPose>(
    prefersReducedMotion ? 'standing' : 'walking'
  );
  const [showText, setShowText] = useState(prefersReducedMotion ? true : false);
  const [showButton, setShowButton] = useState(prefersReducedMotion ? true : false);

  useEffect(() => {
    if (prefersReducedMotion) return;

    const t1 = window.setTimeout(() => setZayanEntered(true), 450);
    const t2 = window.setTimeout(() => {
      setMalaikaPose('surprised');
      soundEngine.playChime();
    }, 1150);
    const t3 = window.setTimeout(() => {
      setZayanPose('waving');
    }, 1600);
    const t4 = window.setTimeout(() => {
      setMalaikaPose('standing');
      setZayanPose('standing');
      setShowText(true);
    }, 2400);
    const t5 = window.setTimeout(() => {
      setShowButton(true);
    }, 3150);

    return () => {
      [t1, t2, t3, t4, t5].forEach((t) => window.clearTimeout(t));
    };
  }, [prefersReducedMotion]);

  return (
    <section className="relative w-full min-h-[calc(100dvh-76px)] flex flex-col items-center justify-center px-5 py-6 text-center">
      <AmbientParticles variant="sparkles" count={10} />

      <div className="relative z-10 w-full max-w-2xl mx-auto flex flex-col items-center gap-6">
        {/* Character Stage */}
        <div className="relative w-full flex items-end justify-center gap-2 sm:gap-8 min-h-[210px] sm:min-h-[245px]">
          <motion.div
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
          >
            <MalaikaCharacter
              pose={malaikaPose}
              lookDirection={malaikaLook}
              size={162}
              className="w-[138px] sm:w-[172px]"
              onTap={() => {
                setMalaikaLook('right');
                soundEngine.playChime();
              }}
            />
          </motion.div>

          <motion.div
            initial={prefersReducedMotion ? { opacity: 1, x: 0 } : { opacity: 0, x: 140 }}
            animate={zayanEntered ? { opacity: 1, x: 0 } : { opacity: 0, x: 140 }}
            transition={{ duration: 1.05, ease: [0.16, 1, 0.3, 1] }}
          >
            <ZayanCharacter
              pose={zayanPose}
              lookDirection="left"
              size={162}
              className="w-[138px] sm:w-[172px]"
              onTap={() => soundEngine.playChime()}
            />
          </motion.div>
        </div>

        {/* Narrative Text */}
        <div className="min-h-[116px] flex flex-col items-center justify-center gap-3 max-w-lg">
          {showText && (
            <>
              <motion.h2
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="font-serif text-[28px] sm:text-[36px] font-semibold leading-[1.25] text-[#2B435B] text-balance"
              >
                Look who&apos;s here!
                <br />
                Today is all about you, birthday boy.
              </motion.h2>

              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.35 }}
                className="font-sans text-[15px] sm:text-[17px] text-[#526E88] leading-relaxed"
              >
                I hope you&apos;re ready for a little adventure.
              </motion.p>
            </>
          )}
        </div>

        {/* Action Button */}
        <div className="min-h-[56px] flex items-center justify-center">
          {showButton && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
            >
              <GlassButton onClick={onNext}>Let&apos;s go! →</GlassButton>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
};
