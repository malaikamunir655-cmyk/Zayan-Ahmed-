import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { MalaikaCharacter } from '../characters/MalaikaCharacter';
import { ZayanCharacter } from '../characters/ZayanCharacter';
import { HuggingCouple } from '../characters/ChibiBase';
import { AmbientParticles } from '../environment/AmbientParticles';
import { GlassButton } from '../ui/GlassButton';
import { soundEngine } from '../../utils/soundEngine';

interface Chapter7Props {
  onNext: () => void;
}

export const Chapter7Hug: React.FC<Chapter7Props> = ({ onNext }) => {
  const prefersReducedMotion = useReducedMotion();
  const [phase, setPhase] = useState<'approach' | 'hugging'>(
    prefersReducedMotion ? 'hugging' : 'approach'
  );
  const [showText, setShowText] = useState(prefersReducedMotion ? true : false);
  const [showButton, setShowButton] = useState(prefersReducedMotion ? true : false);

  useEffect(() => {
    if (prefersReducedMotion) return;

    const t1 = window.setTimeout(() => {
      setPhase('hugging');
      soundEngine.playHugWarmth();
    }, 1500);

    const t2 = window.setTimeout(() => {
      setShowText(true);
    }, 2250);

    const t3 = window.setTimeout(() => {
      setShowButton(true);
    }, 3400);

    return () => {
      [t1, t2, t3].forEach((t) => window.clearTimeout(t));
    };
  }, [prefersReducedMotion]);

  return (
    <section className="relative w-full min-h-[calc(100dvh-76px)] flex flex-col items-center justify-center px-5 py-6 text-center">
      {phase === 'hugging' && <AmbientParticles variant="hearts" count={10} />}

      <div className="relative z-10 w-full max-w-2xl mx-auto flex flex-col items-center gap-6">
        {/* Emotional Hug Sequence */}
        <div className="relative flex items-center justify-center min-h-[230px] sm:min-h-[260px] w-full">
          <AnimatePresence mode="wait">
            {phase === 'approach' ? (
              <motion.div
                key="approaching"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.45 }}
                className="flex items-end justify-center gap-10 sm:gap-16"
              >
                <motion.div
                  animate={{ x: 26 }}
                  transition={{ duration: 1.35, ease: 'easeInOut' }}
                >
                  <MalaikaCharacter
                    pose="blushing"
                    lookDirection="right"
                    size={152}
                    className="w-[128px] sm:w-[158px]"
                  />
                </motion.div>

                <motion.div
                  animate={{ x: -26 }}
                  transition={{ duration: 1.35, ease: 'easeInOut' }}
                >
                  <ZayanCharacter
                    pose="standing"
                    lookDirection="left"
                    size={152}
                    className="w-[128px] sm:w-[158px]"
                  />
                </motion.div>
              </motion.div>
            ) : (
              <motion.div
                key="hugging"
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
                className="flex items-center justify-center"
              >
                <HuggingCouple size={265} className="w-[240px] sm:w-[280px]" />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Emotional Message */}
        <div className="min-h-[144px] flex flex-col items-center justify-center max-w-lg px-2">
          {showText && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="space-y-3"
            >
              <h2 className="font-serif text-[27px] sm:text-[35px] font-semibold leading-[1.25] text-[#2B435B] text-balance">
                Sending you the biggest virtual hug.
              </h2>
              <p className="font-sans text-[15px] sm:text-[17px] text-[#4C6882] leading-relaxed text-balance">
                I hope even on your difficult days, you never forget that someone is wishing the
                best for you.
              </p>
              <p className="font-sans text-[15px] sm:text-[17px] font-medium text-[#354E66]">
                You deserve so much happiness, Zayan.
              </p>
            </motion.div>
          )}
        </div>

        <div className="min-h-[56px] flex items-center justify-center">
          {showButton && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
            >
              <GlassButton onClick={onNext}>One last thing...</GlassButton>
            </motion.div>
          )}
        </div>
      </div>
    </section>
  );
};
