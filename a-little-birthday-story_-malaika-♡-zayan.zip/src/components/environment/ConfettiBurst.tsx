import React, { useMemo } from 'react';
import { motion, useReducedMotion } from 'motion/react';

interface ConfettiBurstProps {
  active: boolean;
  continuous?: boolean;
}

const COLORS = ['#8EB8DC', '#C9E1F5', '#FFFFFF', '#F7DF9C', '#F4B8C6', '#BDE2D8'];

export const ConfettiBurst: React.FC<ConfettiBurstProps> = ({ active, continuous = false }) => {
  const prefersReducedMotion = useReducedMotion();

  const pieces = useMemo(() => {
    return Array.from({ length: 28 }, (_, i) => ({
      id: i,
      left: `${5 + ((i * 19) % 90)}%`,
      color: COLORS[i % COLORS.length],
      width: 6 + (i % 3) * 2,
      height: 10 + (i % 3) * 3,
      delay: (i % 8) * 0.14,
      duration: continuous ? 4.2 + (i % 4) * 0.7 : 2.6 + (i % 4) * 0.4,
      driftX: ((i % 2 === 0 ? 1 : -1) * (18 + (i % 4) * 12)),
      rotate: 180 + (i % 5) * 90,
    }));
  }, [continuous]);

  if (!active || prefersReducedMotion) return null;

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-20" aria-hidden="true">
      {pieces.map((p) => (
        <motion.div
          key={p.id}
          initial={{ y: '-8vh', x: 0, opacity: 0, rotate: 0 }}
          animate={{
            y: '108vh',
            x: [0, p.driftX, -p.driftX * 0.5, p.driftX * 0.6],
            opacity: [0, 1, 1, 0],
            rotate: p.rotate,
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: continuous ? Infinity : 0,
            ease: 'easeOut',
          }}
          style={{
            left: p.left,
            width: p.width,
            height: p.height,
            backgroundColor: p.color,
            borderRadius: p.id % 3 === 0 ? '999px' : '2px',
          }}
          className="absolute top-0 shadow-xs"
        />
      ))}
    </div>
  );
};
