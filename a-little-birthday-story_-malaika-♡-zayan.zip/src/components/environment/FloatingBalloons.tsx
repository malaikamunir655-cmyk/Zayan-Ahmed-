import React from 'react';
import { motion, useReducedMotion } from 'motion/react';

interface BalloonSpec {
  id: number;
  left: string;
  color: string;
  highlight: string;
  scale: number;
  duration: number;
  delay: number;
  sway: number;
  targetY: string;
}

const BALLOONS: BalloonSpec[] = [
  { id: 1, left: '8%', color: '#C9E1F5', highlight: '#ECF5FC', scale: 0.92, duration: 11, delay: 0.1, sway: 14, targetY: '-115vh' },
  { id: 2, left: '20%', color: '#FFFFFF', highlight: '#FFFFFF', scale: 0.78, duration: 13.5, delay: 0.8, sway: -12, targetY: '-115vh' },
  { id: 3, left: '36%', color: '#B5D4EE', highlight: '#E5F2FC', scale: 1.04, duration: 10.2, delay: 0.3, sway: 10, targetY: '-115vh' },
  { id: 4, left: '64%', color: '#F6EBC9', highlight: '#FFFDF5', scale: 0.85, duration: 12.6, delay: 0.5, sway: -16, targetY: '-115vh' },
  { id: 5, left: '79%', color: '#D7ECFA', highlight: '#F4FAFF', scale: 0.98, duration: 9.8, delay: 0.2, sway: 12, targetY: '-115vh' },
  { id: 6, left: '90%', color: '#D4EDE6', highlight: '#F2FAF7', scale: 0.76, duration: 14, delay: 1.1, sway: -10, targetY: '-115vh' },
  { id: 7, left: '50%', color: '#DCEEFF', highlight: '#FFFFFF', scale: 0.72, duration: 15, delay: 1.5, sway: 8, targetY: '-115vh' },
];

interface FloatingBalloonsProps {
  dispersed?: boolean;
  density?: 'normal' | 'finale';
}

export const FloatingBalloons: React.FC<FloatingBalloonsProps> = ({
  dispersed = false,
  density = 'normal',
}) => {
  const prefersReducedMotion = useReducedMotion();
  const list = density === 'finale' ? BALLOONS : BALLOONS.slice(0, 6);

  if (prefersReducedMotion) {
    return (
      <div className="pointer-events-none fixed inset-0 overflow-hidden z-0" aria-hidden="true">
        {list.slice(0, 4).map((b, idx) => (
          <div
            key={b.id}
            style={{ left: b.left, top: `${12 + idx * 14}%`, transform: `scale(${b.scale})` }}
            className="absolute opacity-75"
          >
            <BalloonSvg color={b.color} highlight={b.highlight} />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-0" aria-hidden="true">
      {list.map((b) => (
        <motion.div
          key={b.id}
          initial={{ y: '108vh', x: 0, opacity: 0 }}
          animate={
            dispersed
              ? { y: '-130vh', x: b.sway * 3, opacity: 0 }
              : {
                  y: ['105vh', '-22vh'],
                  x: [0, b.sway, -b.sway * 0.7, b.sway * 0.4, 0],
                  opacity: [0, 0.92, 0.92, 0.85, 0],
                }
          }
          transition={
            dispersed
              ? { duration: 1.1, ease: 'easeIn' }
              : {
                  y: {
                    duration: b.duration,
                    repeat: Infinity,
                    delay: b.delay,
                    ease: 'linear',
                  },
                  x: {
                    duration: b.duration * 0.65,
                    repeat: Infinity,
                    delay: b.delay,
                    ease: 'easeInOut',
                  },
                  opacity: {
                    duration: b.duration,
                    repeat: Infinity,
                    delay: b.delay,
                    times: [0, 0.1, 0.78, 0.92, 1],
                  },
                }
          }
          style={{ left: b.left, scale: b.scale }}
          className="absolute top-0"
        >
          <BalloonSvg color={b.color} highlight={b.highlight} />
        </motion.div>
      ))}
    </div>
  );
};

const BalloonSvg: React.FC<{ color: string; highlight: string }> = ({ color, highlight }) => (
  <svg width="54" height="108" viewBox="0 0 54 108" className="overflow-visible drop-shadow-sm">
    {/* String */}
    <path
      d="M 27 62 Q 22 76 28 88 Q 32 97 26 106"
      fill="none"
      stroke="rgba(95, 123, 149, 0.45)"
      strokeWidth="1.3"
      strokeLinecap="round"
    />
    {/* Balloon knot */}
    <polygon points="24,61 30,61 27,57" fill={color} stroke="rgba(128, 153, 174, 0.4)" strokeWidth="1" />
    {/* Balloon body */}
    <path
      d="M 27 4 C 11 4, 4 17, 4 31 C 4 46, 17 57, 27 58 C 37 57, 50 46, 50 31 C 50 17, 43 4, 27 4 Z"
      fill={color}
      stroke="rgba(255, 255, 255, 0.85)"
      strokeWidth="1.5"
    />
    {/* Gloss reflection */}
    <ellipse cx="17" cy="20" rx="5.5" ry="9.5" transform="rotate(-18 17 20)" fill={highlight} opacity="0.72" />
  </svg>
);
