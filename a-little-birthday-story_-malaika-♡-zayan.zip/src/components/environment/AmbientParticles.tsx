import React, { useMemo } from 'react';
import { motion, useReducedMotion } from 'motion/react';

interface AmbientParticlesProps {
  variant?: 'sparkles' | 'hearts' | 'stars';
  count?: number;
}

export const AmbientParticles: React.FC<AmbientParticlesProps> = ({
  variant = 'sparkles',
  count = 14,
}) => {
  const prefersReducedMotion = useReducedMotion();

  const items = useMemo(() => {
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      left: `${6 + ((i * 37) % 88)}%`,
      top: `${8 + ((i * 29) % 80)}%`,
      size: variant === 'hearts' ? 12 + (i % 3) * 4 : 8 + (i % 4) * 3,
      duration: 3.4 + (i % 5) * 0.8,
      delay: (i % 7) * 0.45,
    }));
  }, [count, variant]);

  if (prefersReducedMotion) {
    return null;
  }

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-0" aria-hidden="true">
      {items.map((item) => (
        <motion.div
          key={`${variant}-${item.id}`}
          initial={{ opacity: 0, scale: 0.6 }}
          animate={
            variant === 'hearts'
              ? {
                  y: [0, -56, -90],
                  opacity: [0, 0.8, 0],
                  scale: [0.7, 1.05, 0.85],
                }
              : {
                  opacity: [0.15, 0.85, 0.15],
                  scale: [0.75, 1.15, 0.75],
                  y: [0, -10, 0],
                }
          }
          transition={{
            duration: item.duration,
            repeat: Infinity,
            delay: item.delay,
            ease: 'easeInOut',
          }}
          style={{ left: item.left, top: item.top }}
          className="absolute"
        >
          {variant === 'hearts' ? (
            <svg width={item.size} height={item.size} viewBox="0 0 24 24" fill="none">
              <path
                d="M12 21C12 21 3 14.8 3 8.8C3 5.8 5.4 3.5 8.2 3.5C9.9 3.5 11.4 4.4 12 5.7C12.6 4.4 14.1 3.5 15.8 3.5C18.6 3.5 21 5.8 21 8.8C21 14.8 12 21 12 21Z"
                fill={item.id % 2 === 0 ? '#9EC5E6' : '#F3AFC0'}
                fillOpacity="0.72"
              />
            </svg>
          ) : (
            <svg width={item.size} height={item.size} viewBox="0 0 24 24" fill="none">
              <path
                d="M12 2L14.2 9.8L22 12L14.2 14.2L12 22L9.8 14.2L2 12L9.8 9.8L12 2Z"
                fill={variant === 'stars' && item.id % 3 === 0 ? '#F9DF96' : '#FFFFFF'}
                fillOpacity="0.88"
              />
            </svg>
          )}
        </motion.div>
      ))}
    </div>
  );
};
