import React from 'react';
import { motion, useReducedMotion } from 'motion/react';

export const DreamySkyScene: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden z-0" aria-hidden="true">
      {/* Drifting fluffy clouds */}
      <motion.div
        animate={prefersReducedMotion ? {} : { x: [-30, 45, -30] }}
        transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-[11%] left-[6%] opacity-85"
      >
        <CloudSvg width={130} />
      </motion.div>

      <motion.div
        animate={prefersReducedMotion ? {} : { x: [35, -35, 35] }}
        transition={{ duration: 26, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-[18%] right-[7%] opacity-80"
      >
        <CloudSvg width={156} />
      </motion.div>

      <motion.div
        animate={prefersReducedMotion ? {} : { x: [-20, 28, -20] }}
        transition={{ duration: 19, repeat: Infinity, ease: 'easeInOut' }}
        className="hidden sm:block absolute top-[28%] left-[26%] opacity-65"
      >
        <CloudSvg width={96} />
      </motion.div>

      {/* Fluttering pastel butterflies */}
      <motion.div
        animate={
          prefersReducedMotion
            ? {}
            : {
                x: [0, 95, 190, 95, 0],
                y: [0, -24, 8, 18, 0],
              }
        }
        transition={{ duration: 13, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-[33%] left-[14%]"
      >
        <ButterflySvg color="#B9D9F3" />
      </motion.div>

      <motion.div
        animate={
          prefersReducedMotion
            ? {}
            : {
                x: [0, -85, -170, -85, 0],
                y: [0, 18, -16, -24, 0],
              }
        }
        transition={{ duration: 15, repeat: Infinity, ease: 'easeInOut', delay: 1.5 }}
        className="absolute top-[42%] right-[16%]"
      >
        <ButterflySvg color="#FFF8D8" />
      </motion.div>

      {/* Soft meadow hill & tiny flowers at the bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-28 sm:h-36">
        <svg viewBox="0 0 1440 160" preserveAspectRatio="none" className="w-full h-full">
          <path
            d="M0 78 Q 360 28 720 68 T 1440 58 L 1440 160 L 0 160 Z"
            fill="rgba(220, 238, 255, 0.72)"
          />
          <path
            d="M0 105 Q 420 55 860 95 T 1440 88 L 1440 160 L 0 160 Z"
            fill="rgba(255, 255, 255, 0.52)"
          />
        </svg>
        {/* Scattered delicate little flowers */}
        <div className="absolute bottom-4 left-[8%]"><TinyFlower color="#FFFFFF" center="#F9DC85" /></div>
        <div className="absolute bottom-7 left-[22%]"><TinyFlower color="#DCEEFF" center="#F9DC85" /></div>
        <div className="absolute bottom-5 left-[44%]"><TinyFlower color="#FFFFFF" center="#F7B2C1" /></div>
        <div className="absolute bottom-8 right-[26%]"><TinyFlower color="#DCEEFF" center="#F9DC85" /></div>
        <div className="absolute bottom-4 right-[10%]"><TinyFlower color="#FFFFFF" center="#F9DC85" /></div>
      </div>
    </div>
  );
};

const CloudSvg: React.FC<{ width: number }> = ({ width }) => (
  <svg width={width} viewBox="0 0 160 72" fill="none">
    <path
      d="M 28 58 H 134 C 146 58, 154 50, 154 39 C 154 29, 146 21, 136 21 C 133 9, 121 2, 108 2 C 95 2, 84 9, 80 20 C 75 15, 67 13, 59 14 C 45 15, 35 26, 35 39 C 24 39, 16 45, 16 51 C 16 55, 21 58, 28 58 Z"
      fill="rgba(255, 255, 255, 0.85)"
    />
  </svg>
);

const ButterflySvg: React.FC<{ color: string }> = ({ color }) => {
  const prefersReducedMotion = useReducedMotion();
  return (
    <motion.svg
      width="26"
      height="22"
      viewBox="0 0 26 22"
      animate={prefersReducedMotion ? {} : { scaleX: [1, 0.45, 1] }}
      transition={{ duration: 0.42, repeat: Infinity, ease: 'easeInOut' }}
    >
      <path d="M 13 11 C 7 2, 1 4, 3 11 C 4 15, 9 15, 13 12 Z" fill={color} stroke="#7CAAD3" strokeWidth="1" />
      <path d="M 13 11 C 19 2, 25 4, 23 11 C 22 15, 17 15, 13 12 Z" fill={color} stroke="#7CAAD3" strokeWidth="1" />
      <path d="M 13 12 C 9 14, 5 18, 8 20 C 11 21, 13 16, 13 13 Z" fill={color} stroke="#7CAAD3" strokeWidth="1" />
      <path d="M 13 12 C 17 14, 21 18, 18 20 C 15 21, 13 16, 13 13 Z" fill={color} stroke="#7CAAD3" strokeWidth="1" />
      <line x1="13" y1="7" x2="13" y2="17" stroke="#5D7D99" strokeWidth="1.5" strokeLinecap="round" />
    </motion.svg>
  );
};

const TinyFlower: React.FC<{ color: string; center: string }> = ({ color, center }) => (
  <svg width="20" height="20" viewBox="0 0 24 24">
    <circle cx="12" cy="6" r="4" fill={color} stroke="#B8D5EC" strokeWidth="0.8" />
    <circle cx="18" cy="11" r="4" fill={color} stroke="#B8D5EC" strokeWidth="0.8" />
    <circle cx="15" cy="17" r="4" fill={color} stroke="#B8D5EC" strokeWidth="0.8" />
    <circle cx="9" cy="17" r="4" fill={color} stroke="#B8D5EC" strokeWidth="0.8" />
    <circle cx="6" cy="11" r="4" fill={color} stroke="#B8D5EC" strokeWidth="0.8" />
    <circle cx="12" cy="12" r="3" fill={center} />
  </svg>
);
