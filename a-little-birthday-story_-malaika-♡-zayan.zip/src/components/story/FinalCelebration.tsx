import React from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { AmbientParticles } from '../environment/AmbientParticles';
import { FloatingBalloons } from '../environment/FloatingBalloons';
import { ConfettiBurst } from '../environment/ConfettiBurst';

export const FinalCelebration: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();

  return (
    <>
      {/* Slowly brightening luminous glow */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.4, ease: 'easeOut' }}
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          background:
            'radial-gradient(circle at 50% 34%, rgba(255, 255, 255, 0.85) 0%, rgba(220, 238, 255, 0.55) 48%, rgba(201, 225, 245, 0.35) 100%)',
        }}
        aria-hidden="true"
      />
      {!prefersReducedMotion && (
        <motion.div
          animate={{ opacity: [0.4, 0.75, 0.4], scale: [0.96, 1.04, 0.96] }}
          transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
          className="pointer-events-none fixed top-1/4 left-1/2 -translate-x-1/2 w-[360px] h-[360px] sm:w-[520px] sm:h-[520px] rounded-full bg-white/50 blur-3xl z-0"
          aria-hidden="true"
        />
      )}
      <FloatingBalloons density="finale" />
      <AmbientParticles variant="stars" count={18} />
      <ConfettiBurst active continuous />
    </>
  );
};
