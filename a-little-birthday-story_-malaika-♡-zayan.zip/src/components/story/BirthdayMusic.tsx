import React, { useEffect, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { soundEngine } from '../../utils/soundEngine';

export const BirthdayMusic: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(soundEngine.isPlaying());

  useEffect(() => {
    return soundEngine.subscribe(setIsPlaying);
  }, []);

  const handleToggle = () => {
    soundEngine.toggleMusic();
  };

  return (
    <button
      type="button"
      onClick={handleToggle}
      aria-label={isPlaying ? 'Pause birthday music' : 'Play birthday music'}
      aria-pressed={isPlaying}
      className="
        glass-button min-h-[44px] min-w-[44px] px-3.5 py-2 rounded-full
        inline-flex items-center gap-2 text-xs font-medium text-[#354E66]
        whitespace-nowrap shrink-0 cursor-pointer transition-all duration-200
        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5C93C4]
      "
    >
      {isPlaying ? (
        <>
          <Volume2 className="w-4 h-4 text-[#5C93C4] shrink-0" aria-hidden="true" />
          <span className="hidden sm:inline">Music</span>
          <span className="flex items-end gap-[2px] h-3" aria-hidden="true">
            <span className="w-[2.5px] h-full bg-[#5C93C4] rounded-full animate-music-bar-1 origin-bottom" />
            <span className="w-[2.5px] h-full bg-[#7CAAD3] rounded-full animate-music-bar-2 origin-bottom" />
            <span className="w-[2.5px] h-full bg-[#5C93C4] rounded-full animate-music-bar-3 origin-bottom" />
          </span>
        </>
      ) : (
        <>
          <VolumeX className="w-4 h-4 text-[#6C87A0] shrink-0" aria-hidden="true" />
          <span className="hidden sm:inline text-[#5F7B95]">Music Off</span>
        </>
      )}
    </button>
  );
};
