import React from 'react';
import { motion, useReducedMotion } from 'motion/react';

interface BirthdayCakeProps {
  litCandles: number; // 0 to 3
  blownOut: boolean;
}

const CANDLE_X = [82, 110, 138];

export const BirthdayCake: React.FC<BirthdayCakeProps> = ({ litCandles, blownOut }) => {
  const prefersReducedMotion = useReducedMotion();

  return (
    <div className="relative inline-flex items-center justify-center select-none">
      <svg width="210" height="196" viewBox="0 0 220 205" className="overflow-visible drop-shadow-[0_14px_26px_rgba(92,147,196,0.18)]">
        {/* Plate */}
        <ellipse cx="110" cy="182" rx="84" ry="13" fill="#FFFFFF" stroke="#B8D5EC" strokeWidth="2.4" />
        <ellipse cx="110" cy="180" rx="68" ry="8" fill="#EFF7FC" />

        {/* Bottom Tier */}
        <rect x="52" y="132" width="116" height="47" rx="14" fill="#FFFFFF" stroke="#B8D5EC" strokeWidth="2.2" />
        <path
          d="M 52 146 Q 66 155 81 146 Q 95 155 110 146 Q 125 155 139 146 Q 154 155 168 146 L 168 138 C 168 133, 162 132, 154 132 L 66 132 C 58 132, 52 133, 52 138 Z"
          fill="#DCEEFF"
        />
        {/* Cute pastel dots on bottom tier */}
        <circle cx="75" cy="164" r="3.5" fill="#9EC5E6" />
        <circle cx="110" cy="166" r="3.5" fill="#F5B8C6" />
        <circle cx="145" cy="164" r="3.5" fill="#F5DC8E" />

        {/* Top Tier */}
        <rect x="68" y="92" width="84" height="42" rx="12" fill="#FFFDF9" stroke="#B8D5EC" strokeWidth="2.2" />
        <path
          d="M 68 104 Q 82 113 96 104 Q 110 113 124 104 Q 138 113 152 104 L 152 97 C 152 93, 146 92, 140 92 L 80 92 C 74 92, 68 93, 68 97 Z"
          fill="#C9E1F5"
        />
        {/* Blue frosting heart */}
        <path
          d="M 110 124 C 110 124, 103 119.5, 103 115.5 C 103 113.5, 104.6 112, 106.5 112 C 108 112, 109.3 113, 110 114.2 C 110.7 113, 112 112, 113.5 112 C 115.4 112, 117 113.5, 117 115.5 C 117 119.5, 110 124, 110 124 Z"
          fill="#8EB8DC"
        />

        {/* Three Candles */}
        {CANDLE_X.map((cx, idx) => {
          const isLit = !blownOut && idx < litCandles;
          return (
            <g key={cx}>
              {/* Candle stick */}
              <rect
                x={cx - 4.5}
                y="58"
                width="9"
                height="34"
                rx="4"
                fill={idx === 1 ? '#F7DF9C' : '#DCEEFF'}
                stroke="#8EB8DC"
                strokeWidth="1.6"
              />
              {/* Diagonal stripe */}
              <line x1={cx - 4} y1="70" x2={cx + 4} y2="66" stroke="#FFFFFF" strokeWidth="2" opacity="0.85" />
              <line x1={cx - 4} y1="81" x2={cx + 4} y2="77" stroke="#FFFFFF" strokeWidth="2" opacity="0.85" />

              {/* Wick */}
              <line x1={cx} y1="53" x2={cx} y2="58" stroke="#5D4942" strokeWidth="1.8" strokeLinecap="round" />

              {/* Lit Flame */}
              {isLit && (
                <g className={prefersReducedMotion ? '' : 'animate-flame'}>
                  {/* Outer glow */}
                  <circle cx={cx} cy="44" r="14" fill="#FFE699" opacity="0.35" />
                  {/* Flame outer */}
                  <path
                    d={`M ${cx} 30 C ${cx + 6} 38, ${cx + 5.5} 49, ${cx} 51 C ${cx - 5.5} 49, ${cx - 6} 38, ${cx} 30 Z`}
                    fill="#FFBD59"
                  />
                  {/* Flame inner */}
                  <path
                    d={`M ${cx} 36 C ${cx + 3} 41, ${cx + 2.8} 48, ${cx} 49.5 C ${cx - 2.8} 48, ${cx - 3} 41, ${cx} 36 Z`}
                    fill="#FFF7C2"
                  />
                </g>
              )}

              {/* Rising Smoke after candles blown out */}
              {blownOut && !prefersReducedMotion && (
                <motion.path
                  initial={{ opacity: 0, y: 0, scale: 0.7 }}
                  animate={{
                    opacity: [0, 0.75, 0],
                    y: [-2, -28, -46],
                    x: [0, idx % 2 === 0 ? -6 : 6, idx % 2 === 0 ? 4 : -4],
                    scale: [0.7, 1.1, 1.3],
                  }}
                  transition={{ duration: 1.8, delay: idx * 0.1, ease: 'easeOut' }}
                  d={`M ${cx} 52 Q ${cx - 5} 44 ${cx + 2} 36 Q ${cx + 7} 29 ${cx} 22`}
                  fill="none"
                  stroke="#99B2C7"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                />
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
};
