import React from 'react';
import { motion, useReducedMotion, Variants } from 'motion/react';

interface ChapterTransitionProps {
  children: React.ReactNode;
  direction?: number;
}

const chapterVariants: Variants = {
  enter: (direction: number) => ({
    opacity: 0,
    x: direction >= 0 ? 28 : -28,
    scale: 0.985,
    filter: 'blur(8px)',
  }),
  center: {
    opacity: 1,
    x: 0,
    scale: 1,
    filter: 'blur(0px)',
    transition: {
      duration: 0.68,
      ease: [0.16, 1, 0.3, 1],
      opacity: { duration: 0.55, ease: 'easeOut' },
      filter: { duration: 0.55, ease: 'easeOut' },
    },
  },
  exit: (direction: number) => ({
    opacity: 0,
    x: direction >= 0 ? -28 : 28,
    scale: 0.985,
    filter: 'blur(8px)',
    transition: {
      duration: 0.52,
      ease: [0.4, 0, 0.2, 1],
      opacity: { duration: 0.45, ease: 'easeInOut' },
    },
  }),
};

const reducedVariants: Variants = {
  enter: { opacity: 0 },
  center: { opacity: 1, transition: { duration: 0.25 } },
  exit: { opacity: 0, transition: { duration: 0.2 } },
};

export const ChapterTransition = React.forwardRef<HTMLDivElement, ChapterTransitionProps>(
  ({ children, direction = 1 }, ref) => {
    const prefersReducedMotion = useReducedMotion();

    return (
      <motion.div
        ref={ref}
        layout
        custom={direction}
        variants={prefersReducedMotion ? reducedVariants : chapterVariants}
        initial="enter"
        animate="center"
        exit="exit"
        className="w-full flex-1 flex flex-col items-center justify-center will-change-[transform,opacity,filter]"
      >
        {children}
      </motion.div>
    );
  }
);

ChapterTransition.displayName = 'ChapterTransition';
