import React, { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, LayoutGroup, motion, useReducedMotion } from 'motion/react';
import { ChevronLeft } from 'lucide-react';
import { CHAPTERS, ChapterId } from '../../types/story';
import { BirthdayMusic } from './BirthdayMusic';
import { ChapterTransition } from './ChapterTransition';
import { Chapter1Surprise } from '../chapters/Chapter1Surprise';
import { Chapter2SomeoneHere } from '../chapters/Chapter2SomeoneHere';
import { Chapter3Journey } from '../chapters/Chapter3Journey';
import { Chapter4Letter } from '../chapters/Chapter4Letter';
import { Chapter5Special } from '../chapters/Chapter5Special';
import { Chapter6Wish } from '../chapters/Chapter6Wish';
import { Chapter7Hug } from '../chapters/Chapter7Hug';
import { Chapter8Finale } from '../chapters/Chapter8Finale';
import { soundEngine } from '../../utils/soundEngine';

export const StoryContainer: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const [currentChapter, setCurrentChapter] = useState<ChapterId>(1);
  const [direction, setDirection] = useState<number>(1);
  const [highestUnlocked, setHighestUnlocked] = useState<ChapterId>(1);

  const goToChapter = useCallback((next: ChapterId) => {
    setCurrentChapter((curr) => {
      setDirection(next >= curr ? 1 : -1);
      return next;
    });
    setHighestUnlocked((prev) => (next > prev ? next : prev));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleNext = useCallback(() => {
    setDirection(1);
    setCurrentChapter((curr) => {
      const next = Math.min(8, curr + 1) as ChapterId;
      setHighestUnlocked((prev) => (next > prev ? next : prev));
      return next;
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handlePrev = useCallback(() => {
    if (currentChapter <= 1) return;
    soundEngine.playClick();
    setDirection(-1);
    setCurrentChapter((curr) => Math.max(1, curr - 1) as ChapterId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentChapter]);

  const handleReplay = useCallback(() => {
    soundEngine.setFinaleMode(false);
    setDirection(-1);
    setCurrentChapter(1);
    setHighestUnlocked(1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    if (currentChapter !== 8) {
      soundEngine.setFinaleMode(false);
    }
  }, [currentChapter]);

  const activeMeta = CHAPTERS[currentChapter - 1];

  return (
    <LayoutGroup>
      <div
        className="relative min-h-[100dvh] w-full flex flex-col overflow-x-hidden transition-colors duration-1000"
        style={{
          background:
            currentChapter === 8
              ? 'linear-gradient(180deg, #F6FBFF 0%, #E4F2FC 55%, #D5EAFA 100%)'
              : 'linear-gradient(180deg, #EFF7FC 0%, #E1F0FB 58%, #CFE4F7 100%)',
        }}
      >
        {/* Persistent Minimal Header Bar (compact for mobile 15% sticky cap) */}
        <header className="sticky top-0 z-30 w-full px-4 sm:px-8 pt-3 pb-2">
          <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
            {/* Left slot: Back navigation or quiet title */}
            <div className="min-w-[84px] flex items-center justify-start">
              <AnimatePresence mode="wait" initial={false}>
                {currentChapter > 1 ? (
                  <motion.button
                    key="back-btn"
                    type="button"
                    onClick={handlePrev}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -6 }}
                    transition={{ duration: 0.2 }}
                    aria-label="Go to previous chapter"
                    className="
                      glass-button min-h-[44px] px-3.5 py-2 rounded-full
                      inline-flex items-center gap-1 text-xs font-medium text-[#354E66]
                      whitespace-nowrap shrink-0 cursor-pointer
                      focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5C93C4]
                    "
                  >
                    <ChevronLeft className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>Back</span>
                  </motion.button>
                ) : (
                  <motion.span
                    key="story-brand"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="font-serif text-[15px] sm:text-base font-semibold text-[#405A73] whitespace-nowrap shrink-0 pl-1"
                  >
                    Malaika ♡ Zayan
                  </motion.span>
                )}
              </AnimatePresence>
            </div>

            {/* Center slot: Subtle Chapter Progress Indicator with shared layoutId */}
            <nav aria-label="Story chapters" className="flex flex-col items-center gap-1.5">
              <div className="flex items-center gap-1.5" role="list">
                {CHAPTERS.map((chap) => {
                  const isActive = chap.id === currentChapter;
                  const isUnlocked = chap.id <= highestUnlocked;
                  return (
                    <button
                      key={chap.id}
                      type="button"
                      disabled={!isUnlocked}
                      onClick={() => {
                        if (!isUnlocked || isActive) return;
                        soundEngine.playClick();
                        goToChapter(chap.id);
                      }}
                      title={`Chapter ${chap.label}: ${chap.title}`}
                      aria-label={`Chapter ${chap.id}: ${chap.title}${isActive ? ' (current)' : ''}`}
                      aria-current={isActive ? 'step' : undefined}
                      className={`
                        relative h-6 px-[2px] flex items-center justify-center
                        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5C93C4] rounded-full
                        ${isUnlocked && !isActive ? 'cursor-pointer' : 'cursor-default'}
                      `}
                    >
                      {isActive ? (
                        <motion.span
                          layoutId="active-chapter-indicator"
                          transition={{ type: 'spring', stiffness: 320, damping: 28 }}
                          className="block h-[5px] w-6 rounded-full bg-[#5C93C4]"
                        />
                      ) : (
                        <span
                          className={`block h-[5px] rounded-full transition-colors duration-300 ${
                            isUnlocked
                              ? 'w-2.5 bg-[#8EB8DC] hover:bg-[#5C93C4]'
                              : 'w-2 bg-[#BBD6EC]/70'
                          }`}
                        />
                      )}
                    </button>
                  );
                })}
              </div>

              <div className="h-4 flex items-center justify-center overflow-hidden">
                <AnimatePresence mode="wait" initial={false}>
                  <motion.span
                    key={activeMeta.id}
                    initial={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: -5 }}
                    transition={{ duration: 0.25 }}
                    className="text-[11px] font-medium tracking-wide text-[#5F7B95] tabular-nums whitespace-nowrap"
                  >
                    {activeMeta.label} / 08 · {activeMeta.title}
                  </motion.span>
                </AnimatePresence>
              </div>
            </nav>

            {/* Right slot: Persistent Music Control */}
            <div className="min-w-[84px] flex items-center justify-end">
              <BirthdayMusic />
            </div>
          </div>
        </header>

        {/* Main Continuous Story Stage with overlapping popLayout cross-fade */}
        <main className="relative flex-1 flex flex-col items-center justify-center w-full overflow-hidden">
          <AnimatePresence mode="popLayout" custom={direction} initial={false}>
            <ChapterTransition key={currentChapter} direction={direction}>
              {currentChapter === 1 && <Chapter1Surprise onNext={handleNext} />}
              {currentChapter === 2 && <Chapter2SomeoneHere onNext={handleNext} />}
              {currentChapter === 3 && <Chapter3Journey onNext={handleNext} />}
              {currentChapter === 4 && <Chapter4Letter onNext={handleNext} />}
              {currentChapter === 5 && <Chapter5Special onNext={handleNext} />}
              {currentChapter === 6 && <Chapter6Wish onNext={handleNext} />}
              {currentChapter === 7 && <Chapter7Hug onNext={handleNext} />}
              {currentChapter === 8 && <Chapter8Finale onReplay={handleReplay} />}
            </ChapterTransition>
          </AnimatePresence>
        </main>
      </div>
    </LayoutGroup>
  );
};
