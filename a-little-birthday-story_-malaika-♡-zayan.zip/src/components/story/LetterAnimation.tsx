import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { GlassButton } from '../ui/GlassButton';
import { GlassCard } from '../ui/GlassCard';
import { soundEngine } from '../../utils/soundEngine';

const LETTER_LINES = [
  'Dear Zayan,',
  "I don't know if I say it enough, but I'm genuinely glad you're here.",
  'I hope life gives you countless reasons to smile, people who make you feel understood, and moments you’ll want to remember forever.',
  'You deserve good things, and I really hope this year brings plenty of them.',
  'Happy birthday, once again. ♡',
];

interface LetterAnimationProps {
  onOpened?: () => void;
  onFinishReveal?: () => void;
}

export const LetterAnimation: React.FC<LetterAnimationProps> = ({
  onOpened,
  onFinishReveal,
}) => {
  const prefersReducedMotion = useReducedMotion();
  const [opened, setOpened] = useState(false);
  const [visibleLines, setVisibleLines] = useState(0);
  const [showSignature, setShowSignature] = useState(false);
  const onFinishRevealRef = React.useRef(onFinishReveal);
  onFinishRevealRef.current = onFinishReveal;

  const handleOpen = () => {
    soundEngine.playEnvelopeOpen();
    setOpened(true);
    onOpened?.();
  };

  useEffect(() => {
    if (!opened) return;

    if (prefersReducedMotion) {
      setVisibleLines(LETTER_LINES.length);
      setShowSignature(true);
      onFinishRevealRef.current?.();
      return;
    }

    const timers: number[] = [];
    LETTER_LINES.forEach((_, idx) => {
      const t = window.setTimeout(() => {
        setVisibleLines(idx + 1);
      }, 450 + idx * 720);
      timers.push(t);
    });

    const sigTimer = window.setTimeout(() => {
      setShowSignature(true);
      onFinishRevealRef.current?.();
    }, 450 + LETTER_LINES.length * 720 + 280);
    timers.push(sigTimer);

    return () => {
      timers.forEach((t) => window.clearTimeout(t));
    };
  }, [opened, prefersReducedMotion]);

  return (
    <div className="w-full max-w-md mx-auto flex flex-col items-center">
      <AnimatePresence mode="wait">
        {!opened ? (
          <motion.div
            key="sealed-envelope"
            initial={{ opacity: 0, y: 18, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.94, filter: 'blur(4px)' }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col items-center gap-6"
          >
            {/* Floating white envelope with blue heart seal */}
            <motion.div
              animate={prefersReducedMotion ? {} : { y: [0, -8, 0], rotate: [-1, 1, -1] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              className="cursor-pointer"
              onClick={handleOpen}
              role="button"
              tabIndex={0}
              aria-label="Tap to open your letter"
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleOpen();
                }
              }}
            >
              <svg width="208" height="140" viewBox="0 0 208 140" className="drop-shadow-[0_14px_28px_rgba(92,147,196,0.2)]">
                <rect
                  x="6"
                  y="10"
                  width="196"
                  height="122"
                  rx="16"
                  fill="#FFFFFF"
                  stroke="#B8D5EC"
                  strokeWidth="2.5"
                />
                {/* Envelope bottom folds */}
                <path d="M 10 128 L 104 68 L 198 128" fill="#F4F9FD" stroke="#D2E5F6" strokeWidth="2" />
                {/* Envelope top flap */}
                <path
                  d="M 8 14 L 104 82 L 200 14"
                  fill="#FAFDFF"
                  stroke="#B8D5EC"
                  strokeWidth="2.4"
                  strokeLinejoin="round"
                />
                {/* Blue Heart Wax Seal */}
                <circle cx="104" cy="79" r="17" fill="#DCEEFF" stroke="#FFFFFF" strokeWidth="2.5" />
                <path
                  d="M 104 88 C 104 88, 94 81.5, 94 75.5 C 94 72.5, 96.4 70.5, 99 70.5 C 101.2 70.5, 103 71.8, 104 73.5 C 105 71.8, 106.8 70.5, 109 70.5 C 111.6 70.5, 114 72.5, 114 75.5 C 114 81.5, 104 88, 104 88 Z"
                  fill="#6FA3D2"
                />
              </svg>
            </motion.div>

            <GlassButton onClick={handleOpen} silent>
              Open your letter ✉
            </GlassButton>
          </motion.div>
        ) : (
          <motion.div
            key="unfolded-letter"
            initial={{ opacity: 0, y: 26, scaleY: 0.84 }}
            animate={{ opacity: 1, y: 0, scaleY: 1 }}
            transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
            style={{ transformOrigin: 'top center' }}
            className="w-full"
          >
            <GlassCard className="relative overflow-hidden bg-white/65 border-white/85 px-6 py-7 sm:px-9 sm:py-9 text-left">
              {/* Subtle stationery lines */}
              <div className="space-y-4">
                {LETTER_LINES.map((line, index) => (
                  <motion.p
                    key={index}
                    initial={{ opacity: 0, y: 8 }}
                    animate={
                      index < visibleLines ? { opacity: 1, y: 0 } : { opacity: 0, y: 8 }
                    }
                    transition={{ duration: 0.55, ease: 'easeOut' }}
                    className={
                      index === 0
                        ? 'font-hand text-[28px] sm:text-[32px] leading-snug text-[#2E4861]'
                        : 'font-hand text-[22px] sm:text-[25px] leading-[1.45] text-[#354E66]'
                    }
                  >
                    {line}
                  </motion.p>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={showSignature ? { opacity: 1, y: 0 } : { opacity: 0, y: 8 }}
                transition={{ duration: 0.6 }}
                className="mt-6 pt-4 border-t border-[#C9E1F5]/70 flex items-end justify-between"
              >
                <div className="font-hand text-[24px] sm:text-[27px] leading-tight text-[#2E4861]">
                  <p>With love,</p>
                  <p className="text-[#4D7FA8] font-semibold">Malaika</p>
                </div>

                {/* Animated heart when letter finishes revealing */}
                {showSignature && (
                  <motion.div
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: [0, 1.2, 1], opacity: 1 }}
                    transition={{ duration: 0.5, ease: 'easeOut' }}
                    aria-hidden="true"
                  >
                    <motion.svg
                      width="28"
                      height="28"
                      viewBox="0 0 24 24"
                      animate={prefersReducedMotion ? {} : { scale: [1, 1.15, 1] }}
                      transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
                    >
                      <path
                        d="M12 21C12 21 3 14.8 3 8.8C3 5.8 5.4 3.5 8.2 3.5C9.9 3.5 11.4 4.4 12 5.7C12.6 4.4 14.1 3.5 15.8 3.5C18.6 3.5 21 5.8 21 8.8C21 14.8 12 21 12 21Z"
                        fill="#7CAAD3"
                      />
                    </motion.svg>
                  </motion.div>
                )}
              </motion.div>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
