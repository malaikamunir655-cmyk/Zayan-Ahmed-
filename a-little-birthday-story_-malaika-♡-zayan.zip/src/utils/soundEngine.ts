// Original synthesized music-box / celesta birthday melody and soft SFX using Web Audio API.
// Zero external audio files required; persists seamlessly across all 8 chapters.

interface NoteStep {
  melody: number | null; // MIDI note
  bass?: number | null;
  harmony?: number | null;
  beats: number;
}

// Original gentle 3/4 waltz birthday theme in C Major / F Major
const MELODY_PATTERN: NoteStep[] = [
  // Phrase 1 (C -> G/B)
  { melody: 72, bass: 48, harmony: 64, beats: 1 }, // C5
  { melody: 76, harmony: 67, beats: 1 }, // E5
  { melody: 79, beats: 1 }, // G5
  { melody: 76, bass: 47, harmony: 62, beats: 1.5 }, // E5
  { melody: 74, beats: 0.5 }, // D5
  { melody: 72, beats: 1 }, // C5

  // Phrase 2 (Am -> F)
  { melody: 74, bass: 45, harmony: 60, beats: 1 }, // D5
  { melody: 76, harmony: 64, beats: 1 }, // E5
  { melody: 72, beats: 1 }, // C5
  { melody: 69, bass: 41, harmony: 60, beats: 2 }, // A4
  { melody: 72, beats: 1 }, // C5

  // Phrase 3 (F -> C/E)
  { melody: 77, bass: 41, harmony: 69, beats: 1 }, // F5
  { melody: 76, harmony: 64, beats: 1 }, // E5
  { melody: 74, beats: 1 }, // D5
  { melody: 76, bass: 40, harmony: 67, beats: 1.5 }, // E5
  { melody: 72, beats: 0.5 }, // C5
  { melody: 74, beats: 1 }, // D5

  // Phrase 4 (Dm7 -> G7 -> C)
  { melody: 72, bass: 43, harmony: 65, beats: 1 }, // C5
  { melody: 74, beats: 1 }, // D5
  { melody: 71, harmony: 67, beats: 1 }, // B4
  { melody: 72, bass: 48, harmony: 64, beats: 3 }, // C5

  // Phrase 5 (Bright lift: Em -> Am)
  { melody: 79, bass: 52, harmony: 67, beats: 1 }, // G5
  { melody: 81, harmony: 72, beats: 1 }, // A5
  { melody: 79, beats: 1 }, // G5
  { melody: 76, bass: 45, harmony: 69, beats: 1.5 }, // E5
  { melody: 74, beats: 0.5 }, // D5
  { melody: 72, beats: 1 }, // C5

  // Phrase 6 (F -> G -> C resolution)
  { melody: 77, bass: 41, harmony: 69, beats: 1 }, // F5
  { melody: 76, harmony: 65, beats: 1 }, // E5
  { melody: 74, beats: 1 }, // D5
  { melody: 72, bass: 48, harmony: 64, beats: 2.5 }, // C5
  { melody: null, beats: 0.5 },
];

function midiToFreq(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private playing = false;
  private finaleMode = false;
  private stepIndex = 0;
  private timerId: number | null = null;
  private listeners = new Set<(isPlaying: boolean) => void>();

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.85;
      this.masterGain.connect(this.ctx.destination);

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.24;
      this.musicGain.connect(this.masterGain);

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 0.36;
      this.sfxGain.connect(this.masterGain);
    }

    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  public subscribe(fn: (isPlaying: boolean) => void): () => void {
    this.listeners.add(fn);
    fn(this.playing);
    return () => {
      this.listeners.delete(fn);
    };
  }

  private notify(): void {
    this.listeners.forEach((fn) => fn(this.playing));
  }

  public isPlaying(): boolean {
    return this.playing;
  }

  public setFinaleMode(enabled: boolean): void {
    this.finaleMode = enabled;
  }

  public startMusic(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    if (this.playing) return;

    this.playing = true;
    this.notify();
    this.scheduleNextStep();
  }

  public pauseMusic(): void {
    this.playing = false;
    if (this.timerId !== null) {
      window.clearTimeout(this.timerId);
      this.timerId = null;
    }
    this.notify();
  }

  public toggleMusic(): boolean {
    if (this.playing) {
      this.pauseMusic();
    } else {
      this.startMusic();
    }
    return this.playing;
  }

  private scheduleNextStep(): void {
    if (!this.playing) return;
    const ctx = this.ensureContext();
    if (!ctx || !this.musicGain) return;

    const step = MELODY_PATTERN[this.stepIndex];
    this.stepIndex = (this.stepIndex + 1) % MELODY_PATTERN.length;

    const beatMs = this.finaleMode ? 430 : 520;
    const durationSec = (step.beats * beatMs) / 1000;
    const now = ctx.currentTime;

    if (step.melody !== null) {
      this.playCelestaNote(midiToFreq(step.melody), now, durationSec * 1.15, 0.28);
      if (this.finaleMode) {
        // Gentle sparkling octave shimmer for Chapter 08 finale
        this.playCelestaNote(midiToFreq(step.melody + 12), now + 0.03, durationSec * 0.9, 0.09);
      }
    }

    if (step.harmony) {
      this.playWarmPadNote(midiToFreq(step.harmony), now, durationSec * 1.2, 0.1);
    }

    if (step.bass) {
      this.playWarmPadNote(midiToFreq(step.bass), now, durationSec * 2.2, 0.14);
    }

    this.timerId = window.setTimeout(() => {
      this.scheduleNextStep();
    }, step.beats * beatMs);
  }

  private playCelestaNote(freq: number, startTime: number, duration: number, peak: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const harmonic = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, startTime);

    harmonic.type = 'triangle';
    harmonic.frequency.setValueAtTime(freq * 2, startTime);

    const harmonicGain = this.ctx.createGain();
    harmonicGain.gain.setValueAtTime(0.18, startTime);
    harmonicGain.gain.exponentialRampToValueAtTime(0.001, startTime + Math.min(duration, 0.45));

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(peak, startTime + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0008, startTime + Math.max(duration, 0.55));

    osc.connect(gain);
    harmonic.connect(harmonicGain);
    harmonicGain.connect(gain);
    gain.connect(this.musicGain);

    osc.start(startTime);
    harmonic.start(startTime);
    osc.stop(startTime + duration + 0.65);
    harmonic.stop(startTime + duration + 0.65);
  }

  private playWarmPadNote(freq: number, startTime: number, duration: number, peak: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, startTime);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(750, startTime);

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(peak, startTime + 0.04);
    gain.gain.exponentialRampToValueAtTime(0.0008, startTime + duration + 0.4);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.musicGain);

    osc.start(startTime);
    osc.stop(startTime + duration + 0.45);
  }

  private playSfxTone(
    freq: number,
    delay: number,
    duration: number,
    peak = 0.2,
    type: OscillatorType = 'sine'
  ): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;
    const t = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);

    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(peak, t + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0008, t + duration);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(t);
    osc.stop(t + duration + 0.05);
  }

  public playClick(): void {
    this.playSfxTone(784, 0, 0.14, 0.14, 'sine');
    this.playSfxTone(1046.5, 0.04, 0.18, 0.1, 'sine');
  }

  public playChime(): void {
    const notes = [659.25, 783.99, 1046.5];
    notes.forEach((n, idx) => {
      this.playSfxTone(n, idx * 0.08, 0.45, 0.12, 'sine');
    });
  }

  public playEnvelopeOpen(): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    // Gentle paper unfold sound via filtered noise
    const bufferSize = Math.floor(ctx.sampleRate * 0.28);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / bufferSize);
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1600, ctx.currentTime);
    filter.Q.setValueAtTime(1.8, ctx.currentTime);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.14, ctx.currentTime + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    noise.start();

    // Followed by a warm two-note chime
    this.playSfxTone(587.33, 0.08, 0.45, 0.14, 'sine');
    this.playSfxTone(880, 0.18, 0.65, 0.15, 'sine');
  }

  public playCandleBlow(): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.sfxGain) return;

    // Soft breathy whoosh
    const bufferSize = Math.floor(ctx.sampleRate * 0.55);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      const env = Math.sin((i / bufferSize) * Math.PI);
      data[i] = (Math.random() * 2 - 1) * env;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(620, ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(280, ctx.currentTime + 0.55);
    filter.Q.setValueAtTime(1.2, ctx.currentTime);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.24, ctx.currentTime + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.55);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    noise.start();

    // Soft celebratory sparkle chord right after blowing
    const chord = [523.25, 659.25, 783.99, 1046.5, 1318.5];
    chord.forEach((freq, i) => {
      this.playSfxTone(freq, 0.36 + i * 0.07, 0.8, 0.13, 'sine');
    });
  }

  public playHugWarmth(): void {
    const chord = [440, 554.37, 659.25];
    chord.forEach((freq, i) => {
      this.playSfxTone(freq, i * 0.1, 1.1, 0.11, 'sine');
    });
  }

  public playFinaleSparkle(): void {
    const notes = [523.25, 659.25, 783.99, 1046.5, 1174.66, 1318.51, 1567.98];
    notes.forEach((freq, i) => {
      this.playSfxTone(freq, i * 0.075, 0.9, 0.14, 'sine');
    });
  }
}

export const soundEngine = new SoundEngine();
