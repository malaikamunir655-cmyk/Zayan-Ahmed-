export type ChapterId = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;

export type CharacterPose =
  | 'peeking'
  | 'standing'
  | 'waving'
  | 'surprised'
  | 'blushing'
  | 'walking'
  | 'holding-letter'
  | 'sitting'
  | 'holding-cake'
  | 'hugging'
  | 'sleeping'
  | 'dancing'
  | 'celebrating';

export type LookDirection = 'center' | 'left' | 'right';

export interface ChapterMeta {
  id: ChapterId;
  title: string;
  label: string;
}

export const CHAPTERS: ChapterMeta[] = [
  { id: 1, title: 'The Little Surprise', label: '01' },
  { id: 2, title: 'Someone Is Here', label: '02' },
  { id: 3, title: 'A Little Journey', label: '03' },
  { id: 4, title: 'A Letter For You', label: '04' },
  { id: 5, title: 'You Are Special', label: '05' },
  { id: 6, title: 'Make A Wish', label: '06' },
  { id: 7, title: 'One Last Hug', label: '07' },
  { id: 8, title: 'Happiest Birthday, Zayan!', label: '08' },
];
